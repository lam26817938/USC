// copyright 2022 Lian

#include "hw2/parse_scores.h"

#include <iostream>
#include <stdexcept>
#include <array>

int GetGradeCount(const std::string input[], size_t size) {
try {
        size_t n = std::stoi(input[1]);
        if (n != size-2)
                n = -1;
        for (size_t i = 2 ; i < size ; i++) {
            if (std::stod(input[i]) < 0)
                n = -1;
        }
        return n;
}catch (const std::invalid_argument& exception) {
        return -1;
}
return 0;
}


std::string GetID(const std::string input[], size_t size) {
try {
        if (size > 1) {
             return input[0];
        } else {
             std::string str = "";
             return str;
             }
        }
catch (const std::invalid_argument& exception) {
        std::string str = "";
        return str;
}
return 0;
}

double GetGrade(size_t grade_index, const std::string input[], size_t size) {
try {
        size_t n = std::stoi(input[1]);
        if (n != size-2)
                return -1;
        for (size_t i = 2 ; i < size ; i++) {
                if (std::stod(input[i]) < 0)
                        return -1;
        }
                if (grade_index < 0 || grade_index > size-3)
                        return -2;
        double t = std::stod(input[grade_index+2]);
        return t;
}catch (const std::invalid_argument& exception) {
        return -1;
}
return 0;
}
double GetMaxGrade(const std::string input[], const size_t kSize) {
try {
                size_t n = std::stoi(input[1]);
                double high = 0.0;
         if (n != kSize-2)
                return -1;
         for (size_t i = 2 ; i < kSize ; i++) {
                if (std::stod(input[i]) > high)
                      high = std::stod(input[i]);
                if (std::stod(input[i]) < 0)
                      return  -1;
               }
        if (n == 0)
                 return -2;

        return high;
}catch (const std::invalid_argument& exception) {
        return -1;
}
return 0;
}
