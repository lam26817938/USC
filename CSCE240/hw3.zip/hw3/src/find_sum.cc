/* Copyright 2021 CSCE 240
*/

#include <hw3/inc/find_sum.h>
#include <hw3/inc/find_sum.h>
#include <cstddef>  // size_t
#include <iostream>

using std::cout;
using std::endl;


size_t** FindHorizontalSum(const int** matrix,
                           const size_t* matrix_size,
                           int search_sum,
                           size_t* sums_found) {
  size_t initial_sum_found = sums_found[0];
  size_t **indices_found = new size_t *[10000];
  for (size_t i =0; i < 10000; ++i) {
    indices_found[i] = new size_t[4];
  }
  int index = 0;
  for (size_t i = 0; i < matrix_size[kMatrix_size_rows_idx]; ++i) {
    for (size_t j = 0; j < matrix_size[kMatrix_size_cols_idx]; ++j) {
      int sum = matrix[i][j];
      for (size_t k = j+1; k < matrix_size[kMatrix_size_cols_idx]; ++k) {
        sum += matrix[i][k];
        if (sum == search_sum) {
          indices_found[index][0] = i;
          indices_found[index][1] = j;
          indices_found[index][2] = i;
          indices_found[index][3] = k;
          sums_found[0]++;
          index++;
        }
      }
    }
  }
  size_t found = sums_found[0] - initial_sum_found;
  size_t **outp = new size_t *[found];
  for (size_t p = 0; p < found; ++p) {
    outp[p] = new size_t[4];
    for (size_t q = 0; q < 4; ++q) {
      outp[p][q] = indices_found[p][q];
    }
    delete [] indices_found[p];
  }
  delete [] indices_found;
  return outp;
}


size_t** FindVerticalSum(const int** matrix,
                         const size_t* matrix_size,
                         int search_sum,
                         size_t* sums_found) {
  size_t initial_sum_found = sums_found[0];
  size_t **indices_found = new size_t *[10000];
  for (size_t i =0; i < 10000; ++i) {
    indices_found[i] = new size_t[4];
  }
  int index = 0;
  for (size_t i = 0; i < matrix_size[kMatrix_size_cols_idx]; ++i) {
    for (size_t j = 0; j < matrix_size[kMatrix_size_rows_idx]; ++j) {
      int sum = matrix[j][i];
      for (size_t k = j+1; k < matrix_size[kMatrix_size_rows_idx]; ++k) {
        sum += matrix[k][i];
        if (sum == search_sum) {
          indices_found[index][0] = j;
          indices_found[index][1] = i;
          indices_found[index][2] = k;
          indices_found[index][3] = i;
          sums_found[0]++;
          index++;
        }
      }
    }
  }
  size_t found = sums_found[0] - initial_sum_found;
  size_t **outp = new size_t *[found];
  for (size_t p = 0; p < found; ++p) {
    outp[p] = new size_t[4];
    for (size_t q = 0; q < 4; ++q) {
      outp[p][q] = indices_found[p][q];
    }
    delete [] indices_found[p];
  }
  delete [] indices_found;
  return outp;
}

size_t** FindDesDiaSum(const int** matrix,
                       const size_t* matrix_size,
                       int search_sum,
                       size_t* sums_found) {
  size_t initial_sum_found = sums_found[0];
  size_t **indices_found = new size_t *[10000];
  for (size_t i =0; i < 10000; ++i) {
    indices_found[i] = new size_t[4];
  }
  int index = 0;
  for (size_t i = 0; i < matrix_size[kMatrix_size_rows_idx]; ++i) {
    for (size_t j = 0; j < matrix_size[kMatrix_size_cols_idx]; ++j) {
      int sum = matrix[i][j];
      for (size_t k = 1; k < matrix_size[kMatrix_size_rows_idx]; ++k) {
        if (i+k < matrix_size[kMatrix_size_rows_idx]
            && j+k < matrix_size[kMatrix_size_cols_idx]) {
          sum += matrix[i+k][j+k];
          if (sum == search_sum) {
            indices_found[index][0] = i;
            indices_found[index][1] = j;
            indices_found[index][2] = i+k;
            indices_found[index][3] = j+k;
            sums_found[0]++;
            index++;
          }
        }
      }
    }
  }
  size_t found = sums_found[0] - initial_sum_found;
  size_t **outp = new size_t *[found];
  for (size_t p = 0; p < found; ++p) {
    outp[p] = new size_t[4];
    for (size_t q = 0; q < 4; ++q) {
      outp[p][q] = indices_found[p][q];
    }
    delete [] indices_found[p];
  }
  delete [] indices_found;
  return outp;
}

size_t** FindAscDiaSum(const int** matrix,
                       const size_t* matrix_size,
                       int search_sum,
                       size_t* sums_found) {
  size_t initial_sum_found = sums_found[0];
  size_t **indices_found = new size_t *[10000];
  for (size_t i =0; i < 10000; ++i) {
    indices_found[i] = new size_t[4];
  }
  int index = 0;
  for (size_t i = 1; i < matrix_size[kMatrix_size_rows_idx]; ++i) {
    for (size_t j = 0; j < matrix_size[kMatrix_size_cols_idx]; ++j) {
      int sum = matrix[i][j];
      for (size_t k = 1; k < matrix_size[kMatrix_size_rows_idx]; ++k) {
        if (i-k < matrix_size[kMatrix_size_rows_idx]
        && i-k >=0 && j+k < matrix_size[kMatrix_size_cols_idx]) {
          sum += matrix[i-k][j+k];
          if (sum == search_sum) {
            indices_found[index][0] = i;
            indices_found[index][1] = j;
            indices_found[index][2] = i-k;
            indices_found[index][3] = j+k;
            sums_found[0]++;
            index++;
          }
        }
      }
    }
  }
  size_t found = sums_found[0] - initial_sum_found;
  size_t **outp = new size_t *[found];
  for (size_t p = 0; p < found; ++p) {
    outp[p] = new size_t[4];
    for (size_t q = 0; q < 4; ++q) {
      outp[p][q] = indices_found[p][q];
    }
    delete [] indices_found[p];
  }
  delete [] indices_found;
  return outp;
}

bool GetSum(const int** matrix,
                   const size_t* matrix_size,
                   int search_sum,
                   size_t* sums_found) {
  if (FindHorizontalSum(matrix, matrix_size, search_sum, sums_found) != nullptr)
    return true;
  if (FindVerticalSum(matrix, matrix_size, search_sum, sums_found) != nullptr)
    return true;
  if (FindDesDiaSum(matrix, matrix_size, search_sum, sums_found) != nullptr)
    return true;
  if (FindAscDiaSum(matrix, matrix_size, search_sum, sums_found) != nullptr)
    return true;
  return false;
}


const size_t** FindSum(const int** matrix,
                       const size_t* matrix_size,
                       int search_sum,
                       size_t* sums_found) {
  sums_found[0] = 0;
  size_t **horizaontal_found
  = FindHorizontalSum(matrix, matrix_size, search_sum, sums_found);
  size_t h_size = sums_found[0];
  size_t **vertical_found
  = FindVerticalSum(matrix, matrix_size, search_sum, sums_found);
  size_t v_size = sums_found[0] - h_size;
  size_t **desdia_found
  = FindDesDiaSum(matrix, matrix_size, search_sum, sums_found);
  size_t dd_size = sums_found[0] - v_size - h_size;
  size_t **acedia_found
  = FindAscDiaSum(matrix, matrix_size, search_sum, sums_found);
  size_t ad_size = sums_found[0] - dd_size - v_size - h_size;

  size_t total = sums_found[0];
  size_t **outp = new size_t *[total];
  size_t index = 0;
  for (size_t i = 0; i < h_size; i++) {
    outp[index] = new size_t[4];
    for (size_t j = 0; j < 4; j++) {
    outp[index][j] = horizaontal_found[i][j];
    }
    index++;
    delete [] horizaontal_found[i];
  }
  delete [] horizaontal_found;

  for (size_t o = 0; o < v_size; o++) {
    outp[index] = new size_t[4];
    for (size_t p = 0; p < 4; p++) {
    outp[index][p] = vertical_found[o][p];
    }
    index++;
    delete [] vertical_found[o];
  }
  delete [] vertical_found;


  for (size_t m = 0; m < dd_size; m++) {
    outp[index] = new size_t[4];
    for (size_t n = 0; n < 4; n++) {
    outp[index][n] = desdia_found[m][n];
    }
    index++;
    delete [] desdia_found[m];
  }
  delete [] desdia_found;


  for (size_t y = 0; y < ad_size; y++) {
    outp[index] = new size_t[4];
    for (size_t z = 0; z < 4; z++) {
    outp[index][z] = acedia_found[y][z];
    }
    index++;
    delete [] acedia_found[y];
  }
  delete [] acedia_found;

  return const_cast<const size_t**>(outp);
}



