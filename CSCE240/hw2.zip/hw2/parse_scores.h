 /*copyright 2021 CSCE240 
*/

#ifndef PARSE_SCORES_H_
#define PARSE_SCORES_H_

#include <cstddef>
#include <string>
#include <iostream>
#include <stdexcept>
#include <array>


/* Description:
 *   Extracts the single highest grade from all student grades
 *
 * Preconditions:
 * - The size_t parameter is the correct size of the input array parameter
 *
 * Parameters:
 * - input: a series of string values representing student ids and grades
 * - size: number of elements in input array
 *
 * Returns:
 * - The highest grade found.
 * - A -1.0 when no students exist
 * - A -2.0 when no grades exist
 * - A -10.0 when the format is corrupt
 */
double GetMaxGrade(const std::string input[], size_t size);


/* Description:
 *   Extracts the number of grades for given student id from the input array
 *
 * Preconditions:
 * - The size_t parameter is the correct size of the input array parameter
 *
 * Parameters:
 * - id: the id of the student for which number of grades is returned
 * - input: a series of string values representing student ids and grades
 * - size: number of elements in input array
 *
 * Returns:
 * - The number of grades for student with parameter id when student id is
 *     found.
 * - A -1 when a match for parameter id is not found in student ids
 * - A -10 when the format is corrupt i.e. 1 1234 3 99.7 82.1
 */
int GetStudentGradeCount(int id, const std::string input[], size_t size);


/* Description:
 *   Extract all student ids from input array and returns them using the output
 *   parameter ids
 *
 * Preconditions:
 * - The size_t parameter is the correct size of the input array parameter
 * - The output parameter array ids is large enough to hold all student id values
 *
 * Postconditions:
 * - Parameter ids has the integer values of the corresponding student ids.
 *
 * Parameters:
 * - input: a series of string values representing student ids and grades
 * - size: number of elements in input array
 * - ids: an output parameter which stores all student ids
 *
 * Returns:
 * - The number of ids parsed
 * - A -10 if format corrupt i.e. 2 1234 1 99.2 2345
 */
int GetStudentIds(const std::string input[], size_t size, int ids[]);


/* Description:
 *   Extracts a single grade for the given student id and grade index.
 *
 * Preconditions:
 * - The size_t parameter is the correct size of the input array parameter
 *
 * Parameters:
 * - id: student id for grade lookup
 * - grade_index: index of grade for look up
 * - input: a series of string values representing student ids and grades
 * - size: number of elements in input array
 *
 * Returns:
 * - Grade selected
 * - A -1.0 when student id is not found
 * - A -2.0 when grade_index is not found
 * - A -10.0 when input format is corrupt
 */
double GetStudentGrade(int id,
                       size_t grade_index,
                       const std::string input[],
                       size_t size);


/* Description:
 *   Extracts all grades for given student id into grades array.
 *
 * Preconditions:
 * - The size_t parameter is the correct size of the input array parameter
 * - The output parameter array grades is large enough to hold all grades for
 *   given student id
 *
 * Postconditions:
 * - Output parameter grades has the floating point value of the grades for the
 *   matching student id
 *
 * Parameters:
 * - id: student id for grades lookup
 * - input: a series of string input representing students and grades
 * - size: number of elements in input array
 * - grades: an output parameter to store floating point value of grades for
 *           given student id
 *
 * Returns:
 * - The number of grades found for student id
 * - A -1 if student id not found
 * - A -10 if format corrupt i.e. q 1234 ; 99.2 89.6
 */
int GetStudentGrades(int id,
                     const std::string input[],
                     size_t size,
                     double grades[]);


/* Description:
 *   Extracts the id(s) of the student(s) with the highest grade and stores in
 *   output array parameter ids
 *
 * Preconditions:
 * - The size_t parameter is the correct size of the input array parameter
 * - The output parameter array ids is large enough to hold all student id values
 *
 * Postconditions:
 * - Output parameter ids contains the integer values of the ids with the
 *   highest grade in the class for the matching student id
 *
 * Parameters:
 * - input: an array of string input representing students and grades
 * - size: number of elements in input array
 * - ids: an output parameter to return the ids of student(s) with the highest
 *        score in the input as integers
 *
 * Returns:
 * - The number of student ids stored in the ids output array
 * - A 0 when no students exist
 * - A -1 when no grades exist
 * - A -10 when the format is corrupt i.e. 1 1234 3 99.7 82.1
 */
int GetMaxGradeStudentId(const std::string input[], size_t size, int ids[]);


const size_t kIdempotency = 0;  // must be present for compilation against my
#endif  //  PARSE_SCORES_H_                             // tests
