#include <hw2/parse_scores.h>

#include <cassert>
#include <iostream>
#include <string>

const std::string kValues[] = {
  "3",
  "345", "2", "87.92", "77.32", 
  "456", "3", "90.23", "81.21", "89.33",
  "567", "1", "100.0"};
int kSize = sizeof(kValues)/sizeof(std::string);

bool TestGetIds();
bool TestGetIdsCorrupt();


int main(int argc, char* argv[]) {
  int passed = 0;

  // test GetStudentIds
  std::cout << "Testing GetStudentIds" << std::endl;
  if (TestGetIds())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  std::cout << "Testing GetStudentIds with corrupt format" << std::endl;
  if (TestGetIdsCorrupt())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  return passed;
}


bool TestGetIds() {
  bool passed = true;
  int expected_return = 3;
  int actual_return;
  int expected_ids[] = { 345, 456, 567 };
  int actual_ids[3];

  actual_return = GetStudentIds(kValues, kSize, actual_ids);

  if (expected_return != actual_return) {
    std::cout << "\tExpected return: " << expected_return
        << ", Actual return: " << actual_return << std::endl;
    passed = false;
  }
  for (int i = 0; i < actual_return; ++i) {
    if (expected_ids[i] != actual_ids[i]) {
      std::cout << "\tExpected id[" << i <<  "]:" << expected_ids[i]
          << " Actual id[" << i <<  "]:" << actual_ids[i] << std::endl;
      passed = false;
    } 
  }

  return passed;
}

bool TestGetIdsCorrupt() {
  int actual_ids[4];
  int expected_return = -10;
  int actual_return = GetStudentIds(kValues, kSize - 2, actual_ids);

  if (expected_return != actual_return) {
    std::cout << "\tExpected return: " << expected_return
        << ", Actual return: " << actual_return << std::endl;
    return false;
  }

  return true; 
}
