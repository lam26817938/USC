#include <hw2/parse_scores.h>
#include <hw2/parse_scores.h>

#include <cassert>
#include <cstddef>
#include <iostream>
#include <string>

const std::string kValues[] = {
  "3",
  "345", "2", "87.92", "100.0", 
  "456", "3", "90.23", "81.21", "89.33",
  "567", "1", "100.0"};
size_t kSize = sizeof(kValues)/sizeof(std::string);

bool TestGetMaxGradeId();
bool TestGetMaxGradeIdNoStudents();
bool TestGetMaxGradeIdNoGrades();
bool TestGetMaxGradeIdCorruptFormat();


int main(int argc, char* argv[]) {
  assert(kIdempotency == 0);
  int passed = 0;

  // testing GetMaxGradeStudentId 
  std::cout << "Testing GetMaxGradeStudentId" << std::endl;
  if (TestGetMaxGradeId())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  std::cout << "Testing GetMaxGradeStudentId with no students" << std::endl;
  if (TestGetMaxGradeIdNoStudents())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  std::cout << "Testing GetMaxGradeStudentId with no grades" << std::endl;
  if (TestGetMaxGradeIdNoGrades())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  std::cout << "Testing GetMaxGradeStudentId with corrupt format" << std::endl;
  if (TestGetMaxGradeIdCorruptFormat())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  return passed;
}


bool TestGetMaxGradeId() {
  const size_t kExpected_ids_size = 2;
  const int kExpected_ids[] = { 345, 567 };
  int actual_ids[kSize];  // large enough to contain all students
  int actual_ids_size = GetMaxGradeStudentId(kValues, kSize, actual_ids);
  bool found_all = true;

  if (kExpected_ids_size != actual_ids_size) {
    std::cout << "\tExpected ids found: " << kExpected_ids_size
              << ", Actual ids found: " << actual_ids_size << std::endl;
    return false;
  }

  for (size_t i = 0; i < kExpected_ids_size; ++i) {
    bool found = false;
    for (size_t ii = 0; ii < static_cast<size_t>(actual_ids_size); ++ii)
      if (kExpected_ids[i] == actual_ids[ii])
        found = true;
    found_all = found_all && found;
  }

  if (!found_all) {
    std::cout << "\tOne or more Ids missing or incorrect." << std::endl;
    return false;
  }

  return true;
}


bool TestGetMaxGradeIdNoStudents() {
  const int kExpected_ids_count = 0;
  std::string values[] = { "0" };
  int actual_ids_found[kSize];
  int actual_ids_count = GetMaxGradeStudentId(values, 1, actual_ids_found);
  if (kExpected_ids_count != actual_ids_count) {
    std::cout << "\tExpected number of students found: " << kExpected_ids_count
              << ", Actual number of students found: " << actual_ids_count
              << std::endl;
    return false;
  }

  return true;
}


bool TestGetMaxGradeIdNoGrades() {
  const int kExpected_ids_count = -1;
  const std::string kValues[] = { "3", "234", "0", "345", "0", "456", "0" };
  const size_t kValues_size = 7;
  int actual_ids_found[kSize];
  int actual_ids_count = GetMaxGradeStudentId(kValues,
                                              kValues_size,
                                              actual_ids_found);
  if (kExpected_ids_count != actual_ids_count) {
    std::cout << "\tExpected number of students found: " << kExpected_ids_count
              << ", Actual number of students found: " << actual_ids_count
              << std::endl;
    return false;
  }

  return true;
}


bool TestGetMaxGradeIdCorruptFormat() {
  const int kExpected_ids_count = -10;
  std::string values[] = { ";", "234", "a", "345", "0", "456", "0" };
  int actual_ids_found[kSize];
  int actual_ids_count = GetMaxGradeStudentId(values, 3, actual_ids_found);
  if (kExpected_ids_count != actual_ids_count) {
    std::cout << "\tExpected number of students found: " << kExpected_ids_count
              << ", Actual number of students found: " << actual_ids_count
              << std::endl;
    return false;
  }

  return true;
}
