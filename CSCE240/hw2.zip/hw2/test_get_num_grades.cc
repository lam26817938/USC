#include <hw2/parse_scores.h>

#include <iostream>
#include <string>

std::string kValues[] = {
  "3",
  "345", "2", "87.92", "77.32", 
  "456", "3", "90.23", "81.21", "89.33",
  "567", "1", "100.0"};
int kSize = sizeof(kValues)/sizeof(std::string);

bool TestGetNumGrades();
bool TestGetNumGradesNoMatch();
bool TestGetNumGradesCorrupt();

int main(int argc, char* argv[]) {
  int passed = 0;
  // test GetStudentGradeCount
  std::cout << "Testing GetStudentGradeCount" << std::endl;
  if (TestGetNumGrades()) {
    std::cout << "  PASSED" << std::endl;
  } else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  std::cout << "Testing GetStudentGradeCount with no match" << std::endl;
  if (TestGetNumGradesNoMatch()) {
    std::cout << "  PASSED" << std::endl;
  } else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  std::cout << "Testing GetStudentGradeCount with corrupt format" << std::endl;
  if (TestGetNumGradesCorrupt()) {
    std::cout << "  PASSED" << std::endl;
    return 0;
  } else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  return passed;
}

bool TestGetNumGrades() {
  bool passed = true;
  int expected, actual;

  expected = 2;
  actual = GetStudentGradeCount(345, kValues, kSize);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    passed = false;
  }

  expected = 3;
  actual = GetStudentGradeCount(456, kValues, kSize);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    passed = false;
  }

  expected = 1;
  actual = GetStudentGradeCount(567, kValues, kSize);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    passed = false;
  }

  return passed;
}


bool TestGetNumGradesNoMatch() {
  bool passed = true;
  int expected, actual;

  expected = -1;
  actual = GetStudentGradeCount(678, kValues, kSize);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    passed = false;
  }

  return passed;
}


bool TestGetNumGradesCorrupt() {
  bool passed = true;
  int expected, actual;

  expected = -10;
  actual = GetStudentGradeCount(567, kValues, kSize - 1);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    passed = false;
  }

  return passed;
}
