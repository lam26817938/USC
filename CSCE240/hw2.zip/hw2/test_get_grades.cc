#include <hw2/parse_scores.h>
#include <hw2/parse_scores.h>

#include <cassert>
#include <iostream>
using std::cin;
using std::cout;
using std::endl;
#include <string>

std::string kValues[] = {
  "3",
  "345", "2", "87.92", "77.32", 
  "456", "3", "90.23", "81.21", "89.33",
  "567", "1", "100.0"};
int kSize = sizeof(kValues)/sizeof(std::string);

bool TestGetStudentGrades();
bool TestGetStudentGradesNoMatch();
bool TestGetStudentGradesCorrupt();


int main(int argc, char* argv[]) {
  assert(kIdempotency == 0);
  int passed = 0;

  // test GetStudentGrades
  cout << "Testing GetStudentGrades" << endl;
  if (TestGetStudentGrades())
    cout << "  PASSED" << endl;
  else {
    cout << "  FAILED" << endl;
    passed = 1;
  }

  cout << "Testing GetStudentGrades with no matching id" << endl;
  if (TestGetStudentGradesNoMatch())
    cout << "  PASSED" << endl;
  else {
    cout << "  FAILED" << endl;
    passed = 1;
  }

  cout << "Testing GetStudentGrades with corrupt format" << endl;
  if (TestGetStudentGradesCorrupt())
    cout << "  PASSED" << endl;
  else {
    cout << "  FAILED" << endl;
    passed = 1;
  }

  return passed;
}


bool TestGetStudentGrades() {
  bool passed = true;
  int expected_return[] = {2, 3, 1};
  int actual_return;
  double expected_grades[][3] = {
      { 87.92, 77.32, 0.0 },
      { 90.23, 81.21, 89.33 },
      { 100.0, 0.0, 0.0}
  };
  double actual_grades[4];
  int ids[] = { 345, 456, 567 };
  int num_grades[] = {2, 3, 1};

  for (int i = 0; i < 3; ++i) {
    actual_return = GetStudentGrades(ids[i], kValues, kSize, actual_grades);
    if (expected_return[i] != actual_return) {
      cout << "\tExpected Return: " << expected_return[i] << ", Actual Return: "
          << actual_return << endl;
      passed = false;
    }
    for (int j = 0; j < num_grades[i]; ++j) {
      if (expected_grades[i][j] != actual_grades[j]) {
        cout << "\tExpected[" << j << "]: " << expected_grades[i][j]
            << ", Actual [" << j << "]: " << actual_grades[j] << endl;
        passed = false;
      }
    }
  }

  return passed;
}

bool TestGetStudentGradesNoMatch() {
  double dummy_data[4];
  int expected_num_grades = -1;
  int actual_num_grades = GetStudentGrades(4567, kValues, kSize, dummy_data);
  if (expected_num_grades != actual_num_grades) {
    cout << "\tExpected return: " << expected_num_grades
        << ", Actual return: " << actual_num_grades << endl;
    return false;
  }

  return true; 
}

bool TestGetStudentGradesCorrupt() {
  double dummy_data[4];
  int expected_num_grades = -10;
  int actual_num_grades = GetStudentGrades(456, kValues, kSize - 5, dummy_data);
  if (expected_num_grades != actual_num_grades) {
    cout << "\tExpected return: " << expected_num_grades
        << ", Actual return: " << actual_num_grades << endl;
    return false;
  }

  return true; 
}
