 /*copyright 2021 CSCE240 
*/
#include <hw2/parse_scores.h>
#include <hw2/parse_scores.h>

using std::cin;
using std::cout;
using std::endl; 
using std::array;

double GetMaxGrade(const std::string input[], size_t size){
try{
	size_t index = 0;
	if(index>= size){
		return -10.0;
	}
  	size_t student_no = std::stoi(input[index]);
  	if (student_no == 0){
  		return -1.0;
  	}
  	index++;
  	double max_score = -2.0;
  	for(::size_t i=0; i < student_no; i++){
  		int id = std::stoi(input[index]);
  		if (id <=0){
  			return -1.0;
  		}
  		index++;
  		int grade_number = std::stoi(input[index]);
  		index++; 
  		double score = 0.0;  		
  		for(int j = 0; j< grade_number; j++){
			score= std::stod(input[index]);
			if(score > max_score){
  			max_score = score;
  			}
  		index++;  			 			 
  		}
  	}
  	if(index !=size){
  		return -10;
  	}
  	return max_score;
}catch (const std::invalid_argument& exception) {
	return -10;// non-numeric student number
}
return 0;
}

int GetStudentGradeCount(int id, const std::string input[], size_t size){
try{	
	size_t index = 0;	
  	int student_no = std::stoi(input[index++]);
  	int i;
  	for( i=0; i < student_no; i++){
  		index++;
  		int grade_number =  std::stoi(input[index++]);
  		for(int j=0; j< grade_number; j++){
  			index++;
  		}	
  					
	}
	if(index != size){
		return -10;
	}
	index = 0;	
  	index++;
  	for(i=0; i < student_no; i++){
  		if(std::stoi(input[index++]) == id)
  		{
  			return std::stoi(input[index++]);
  		} 		
  		int grade_number =  std::stoi(input[index++]);
  		for(int j=0; j< grade_number; j++){
  			index++;
  		}			
	}
	return -1;
}catch (const std::invalid_argument& exception) {
	return -10;
}
}



int GetStudentIds(const std::string input[], size_t size, int ids[]){
try{	
	size_t index = 0;	
  	int student_no = std::stoi(input[index++]);  	
  	int a = 0;
  	double temp;
  	int grade_number;  	
  	for(int i=0; i < student_no; i++){
  		ids[a++] = std::stoi(input[index++]);   		
  		grade_number = std::stoi(input[index++]);  		
 		for(int j = 0; j< grade_number; j++){
			temp = std::stod(input[index++]);		
  			temp++;
  			
		}
	}
	if(index != size){  			
  		return -10;
  	}
	return student_no;
}catch (const std::invalid_argument& exception) {
	return -10;
}
}


double GetStudentGrade(int id,
                       size_t grade_index,
                       const std::string input[],
                       size_t size){
try{	
	size_t index = 0;	
  	int student_no = std::stoi(input[index++]);
  	int i;
  	for( i=0; i < student_no; i++){
  		index++;
  		int grade_number =  std::stoi(input[index++]);
  		for(int j=0; j< grade_number; j++){
  			index++;
  		}  					
	}
	if(index != size){
		return -10.0;
	}
	index = 0;	
  	index++;
  	for(i=0; i < student_no; i++){
  		if(std::stoi(input[index++]) == id)
  		{
  			size_t gn = std::stoi(input[index++]);
  			if(grade_index >= gn){
  				return -2.0;
  			}
  			return std::stod(input[index+grade_index]);  			} 		
  		int grade_number =  std::stoi(input[index++]);
  		for(int j=0; j< grade_number; j++){
  			index++;
  		}			
	}
	return -1.0;
}catch (const std::invalid_argument& exception) {	
	return -10.0;
}  
}
                       
int GetStudentGrades(int id,
                     const std::string input[],
                     size_t size,
                     double grades[]){
try{	
	size_t index = 0;	
  	int student_no = std::stoi(input[index++]);
  	int i;
  	for( i=0; i < student_no; i++){
  		index++;
  		int grade_number =  std::stoi(input[index++]);
  		for(int j=0; j< grade_number; j++){
  			index++;
  		}  					
	}
	if(index != size){
		return -10;
	}
	index = 0;	
  	index++;
  	for(i=0; i < student_no; i++){
  		if(std::stoi(input[index++]) == id)
  		{  			
  			int gn = std::stoi(input[index++]);
  			for(int j = 0; j < gn; j++){
  				grades[j] = std::stod(input[index++]);
  			}
  			return gn;
  		} 		
  		int grade_number =  std::stoi(input[index++]);
  		for(int j=0; j< grade_number; j++){
  			index++;
  		}			
	}
	return -1;
}catch (const std::invalid_argument& exception) {	
	return -10;
}
}

int GetMaxGradeStudentId(const std::string input[], size_t size, int ids[]){
try{
	size_t index = 0;
  	int student_no = std::stoi(input[index++]);
  	if (student_no == 0){
  		return 0;
  	}
  	double max_score = -2.0;
  	for(int i=0; i < student_no; i++){
  		index++;
  		int grade_number = std::stoi(input[index++]); 
  		double score = 0.0;  		
  		for(int j = 0; j< grade_number; j++){
			score= std::stod(input[index++]);
			if(score > max_score){
  			max_score = score;
  			}  			 			 
  		}
  	}
  	if(index !=size){
  		return -10;
  	}
  	index = 1;
  	int ids_index = 0;
  	for(int i=0; i < student_no; i++){
  		int id = std::stoi(input[index++]);
  		int grade_number = std::stoi(input[index++]); 
  		double score = 0.0;  	
  		bool is_max = false;	
  		for(int j = 0; j< grade_number; j++){
			score= std::stod(input[index++]);
			if(score == max_score){
  				is_max = true;
  			}  			 			 
  		}
  		if(is_max){
  			ids[ids_index++]=id;
  		}
  	}
  	if(ids_index == 0){
  		return -1;
  	}
  	return ids_index;
  	 
}catch (const std::invalid_argument& exception) {
	return -10;
}
}


  
  

 
 
 







