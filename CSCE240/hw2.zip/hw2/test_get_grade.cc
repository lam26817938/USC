#include <hw2/parse_scores.h>

#include <cstddef>
#include <iostream>
#include <string>

std::string kValues[] = {
  "3",
  "345", "2", "87.92", "77.32", 
  "456", "3", "90.23", "81.21", "89.33",
  "567", "1", "100.0"
};
size_t kSize = sizeof(kValues)/sizeof(std::string);

bool TestGetGrade();
bool TestGetGradeNoMatch();  // true when returns -1 for no matching id
bool TestGetGradeNoIndex();  // true when returns -2 for missing index
bool TestGetGradeFormatCorrupt();  // true when returns -10 for corrupt format


int main(int argc, char* argv[]) {
  int passed = 0;
  // test get_num_grades
  std::cout << "Testing GetStudentGrade" << std::endl;
  if (TestGetGrade())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }
  
  std::cout << "Testing GetStudentGrade with no matching student id" << std::endl;
  if (TestGetGradeNoMatch())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }
  
  std::cout << "Testing GetStudentGrade with no matching grade index"
            << std::endl;
  if (TestGetGradeNoIndex())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }
  
  std::cout << "Testing GetStudentGrade with format corrupt" << std::endl;
  if (TestGetGradeFormatCorrupt())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  return passed;
}


bool TestGetGrade() {  // true when correct grade selected for given id
  int ids[] = { 345, 456, 567 };
  int grade_index[] = { 1, 1, 0 };
  double expected_grades[] = { 77.32, 81.21, 100.0 };
  bool passed = true;

  for (unsigned int i = 0; i < sizeof(ids)/sizeof(int); ++i) {
    double actual_grade = GetStudentGrade(ids[i],
                                          grade_index[i],
                                          kValues,
                                          kSize);

    if (expected_grades[i] != actual_grade) {
      std::cout << "\tExpected Grade at " << i << ": " << expected_grades[i]
                << " Actual Grade : " << actual_grade << std::endl;
      passed = false;
    }
  }
  return passed;
}


bool TestGetGradeNoMatch() {  // true when returns -1 for no matching id
  double expected = -1;
  double actual = GetStudentGrade(1234, 2, kValues, kSize);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    return false;
  }

  return true;
}


bool TestGetGradeNoIndex() {
  double expected = -2;
  double actual = GetStudentGrade(456, 3, kValues, kSize);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    return false;
  }

  return true;
}


bool TestGetGradeFormatCorrupt() {
  double expected = -10;
  double actual = GetStudentGrade(345, 1, kValues, kSize-5);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    return false;
  }

  return true;
}
