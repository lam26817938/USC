#include <hw2/parse_scores.h>

#include <iostream>
#include <string>

std::string kValues[] = {
  "3",
  "345", "2", "87.92", "77.32", 
  "456", "3", "90.23", "81.21", "89.33",
  "567", "1", "100.0"};
int kSize = sizeof(kValues)/sizeof(std::string);


bool TestGetMaxGrade();
bool TestGetMaxGradeNoStudents();  // true when returns -1 when no student exist
bool TestGetMaxGradeNoGrades();  // true when returns -2 when no grades exist
bool TestGetMaxGradeFormatCorrupt();  // true when returns -10 for corrupt format


int main(int argc, char* argv[]) {
  int passed = 0;

  std::cout << "Testing GetMaxGrade" << std::endl;
  if (TestGetMaxGrade())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  std::cout << "Testing GetMaxGrade with no students exist" << std::endl;
  if (TestGetMaxGradeNoStudents())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  std::cout << "Testing GetMaxGrade with no grades exist" << std::endl;
  if (TestGetMaxGradeNoGrades())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  std::cout << "Testing GetMaxGrade with format corrupt" << std::endl;
  if (TestGetMaxGradeFormatCorrupt())
    std::cout << "  PASSED" << std::endl;
  else {
    std::cout << "  FAILED" << std::endl;
    passed = 1;
  }

  return passed;
}


bool TestGetMaxGrade() {  // true when max grade found
  double expected_max_grade = 100.0;
  double actual_max_grade = GetMaxGrade(kValues, kSize);
  if (expected_max_grade != actual_max_grade) {
    std::cout << "\tExpected max grade: " << expected_max_grade
        << ", Actual max grade: " << actual_max_grade << std::endl;
    return false;
  }

  return true;
}


bool TestGetMaxGradeNoStudents() {  // true when returns -1 when no student exist
  int expected = -1;
  std::string values[] = { "0" };
  int actual = GetMaxGrade(values, 1);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    return false;
  }

  return true;
}


bool TestGetMaxGradeNoGrades() {  // true when returns -2 when no grades exist
  int expected = -2;
  std::string values[] = { "3", "1234", "0", "2345", "0", "3456", "0" };
  int actual = GetMaxGrade(values, 7);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    return false;
  }

  return true;
}


bool TestGetMaxGradeFormatCorrupt() {
  double expected = -10;
  double actual = GetMaxGrade(kValues, kSize-2);
  if (expected != actual) {
    std::cout << "\tExpected: " << expected << ", Actual: " << actual << std::endl;
    return false;
  }

  return true;
}
