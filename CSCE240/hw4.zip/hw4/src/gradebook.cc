/*Copyright 2021 CSCE 240
*/

#include <hw4/inc/gradebook.h>
#include <hw4/inc/gradebook.h>
#include <cassert>
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <string>
#include <sstream>

using std::istream;
using std::ostream;
using std::string;

  GradeBook::GradeBook() {}


  void GradeBook::Add(const Grade& element) {
    grades.push_back(element);
  }
  
  const Grade GradeBook::Get(unsigned int index) const {
    size_t s = grades.size();
    if (s < index+1) {
      return Grade(0,1);
    }
    else {
      return grades[index];
    } 
  }

  const GradeBook GradeBook::Add(const GradeBook& gb) const {                                                           
    GradeBook gradebook;
    for(Grade g:grades) {
      gradebook.Add(g);
    }
    for (Grade g:gb.getgrades()) {
      gradebook.Add(g);
    }
    return gradebook;
  }
  
  const Grade GradeBook::CalcAverage() const{
    size_t s = grades.size();
    unsigned int fz = 0;
    unsigned int fm = 0;
    if (s <= 0) {
      return Grade(1,1);
    }
    else {
      for(unsigned int i = 0; i < s; i++) {
       fz += grades[i].scored();
       fm += grades[i].total();
      }
      return Grade(fz,fm);
    }
  }
  
  
