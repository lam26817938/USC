/*Copyright 2021 CSCE 240
*/

#include <hw4/inc/grade.h>
#include <cassert>
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <string>
#include <sstream>

using std::istream;
using std::ostream;
using std::string;

Grade::Grade() {
  scored_ = 0;
  total_ = 1;
}

Grade::Grade(unsigned int scored, unsigned int total) {
  scored_ = scored;
  total_ = total;
}

  double Grade::ToDouble() const {
    double dPoints = ((int)((1.0*scored_)/(1.0*total_)
                      *pow(10, 6)+5)/10)/pow(10, 3);
    return dPoints;
  }
  double Grade::ToDouble(unsigned int precision) const {
    double dPoints =  ((int)((1.0*scored_)/(1.0*total_)
                      *pow(10, precision+3)+5)/10)/pow(10, precision);
    return dPoints;
  }

  string Grade::ToString() const {
    if (scored_ == 0 && total_ != 0) {
      return "0";
    } else {
      return std::to_string(scored_) + "/" + std::to_string(total_);
    }
  }


  string Grade::ToLetter() const {
    double temp = (1.0*scored_)/(1.0*total_)*100.0;
    if (temp >= 90.0) {
      return string("A");
    } else if (temp >= 80.0 && temp < 90) {
      return string("B");
    } else if (temp >= 70.0 && temp < 80) {
      return string("C");
    } else if (temp >= 60.0 && temp < 70) {
      return string("D");
    } else {
      return string("F");
    }
  }
  string Grade::ToLetter(unsigned int t) const {
    double temp = (1.0*scored_)/(1.0*total_)*100.0;
    if (temp >= 100)
      return string("A+");
    double temp1 = floor(temp/10)*10;
    bool withplus = false;
    if ((temp-temp1)*10 >=t) {
      withplus = true;
    }
    if (temp >= 90.0) {
      return string("A")+(withplus ? "+" : " ");
    } else if (temp >= 80.0 && temp < 90) {
      return string("B") + (withplus ? "+" : " ");
    } else if (temp >= 70.0 && temp < 80) {
      return string("C") + (withplus ? "+" : " ");
    } else if (temp >= 60.0 && temp < 70) {
      return string("D") + (withplus ? "+" : " ");
    } else {
      return string("F");
    }
  }
  bool Grade::Equals(const Grade& rhs) const {
    unsigned int tempscoredlhs = scored_*rhs.total_;
    unsigned int tempscoredrhs = rhs.scored_*total_;
    if ( tempscoredlhs == tempscoredrhs)
      return true;
    else
      return false;
  }

  Grade Grade::DividedBy(const Grade& rhs) const {
    unsigned int tempscored = scored_*rhs.total_;
    unsigned int temptotal = rhs.scored_*total_;
    unsigned int up = 0;
    unsigned int down = 0;
    if (tempscored > temptotal || tempscored % temptotal == 0) {
      up = tempscored/temptotal;
      down = 1;
    } else if (tempscored < temptotal || temptotal % tempscored == 0) {
      up = 1;
      down = temptotal / tempscored;
    } else {
      up = tempscored;
      down = temptotal;
    }
    return Grade(up, down);
  }

  Grade Grade::Plus(const Grade& rhs) const {
    unsigned int scored = scored_*rhs.total_ + rhs.scored_*total_;
    unsigned int total = total_ *rhs.total_;
    return Grade(scored, total);
  }
