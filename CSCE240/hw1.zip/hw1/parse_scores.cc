#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(int argc, char* argv[]) {
  // The following input
  //
  //   3 1 2 60 40 2 3 10 20 30 3 1 25
  //
  // would result in the following output.
  //
  
  int max_stu_id=0;
  int max_score=0;
  int stu_num;
  cin >> stu_num;
  cout << "{" << endl;    
  cout << "  \"students\" : [" << endl; 
  
  for(int i = 0; i < stu_num; i++){
  	int id;
  	cin>>id;
  	//result = result + id;
  	
  	
  	int score_num ;
  	cin >> score_num;
  	std::string score_line;
  	
  	for(int j = 0; j< score_num; j++){
  		double score;
  		cin >> score;
  		if(score > max_score){
  			max_score = score;
  			max_stu_id=id;
  		}
  		if(j==0){
  			score_line += std::to_string(score);
  		}else{
  			score_line += "," + std::to_string(score);
  		}
  	}
  	if(i == stu_num -1){
  	cout << " { \"id\" : " << id <<", \"grades\" : [" << score_line <<" ] }"<< endl;
  	}else{
   cout << " { \"id\" : " << id <<", \"grades\" : [" << score_line <<" ] },"<< endl;
  }
  }
  cout << " ],"<< endl;
  cout << "  \"max_id\" : " << max_stu_id << ","<< endl;
  cout << "  \"max_score\" : " << max_score << endl;
  cout << "}"<< endl;

return 0;
}
