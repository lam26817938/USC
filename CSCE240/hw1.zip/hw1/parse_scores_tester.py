#!/usr/bin/env python3
"""Module documentation goes here
"""

import json
import subprocess
import sys


class QuickTest:
    """Class documentation goes here
    """

    # private const static variables
    _APP = "./parse_scores"
    _INPUT = [
        # data_idx == 0
        """3 4 2 70.0 30.0 5 3 20.0 95.0 40.0 6 2 80.0 85.0""",
        # data_idx == 1
        """1 3433 8 75.1 89.9 90.5 90.1 87.6 88.4 89.6 89.9""",
        # data_idx == 2
        """4 47 4 90.8 89.7 85.6 89.9 64 2 91.8 88.6 89 3 89.8 90.2 94.7 71 1 67.4"""
    ]
    _GRADES = [{ # data_idx == 0
        4 : [70, 30],
        5 : [20, 95, 40],
        6 : [80, 85]
    }, {             # data_idx == 1
        3433 : [75.1, 89.9, 90.5, 90.1, 87.6, 88.4, 89.6, 89.9]
    }, {             # data_idx == 2
        47 : [90.8, 89.7, 85.6, 89.9],
        64 : [91.8, 88.6],
        89 : [89.8, 94.7, 90.2],
        71 : [67.4],
    }]
    _MAX_ID = [
        5,  # data_idx == 0
        3433,  # . . .
        89
    ]
    _MAX_SCORE = [
        95, # . . .
        90.5,
        94.7
    ]

    def run(self):
        """Method documentation goes here.
        """
        return_code = 0
        if self.file_name:
            with open(self.file_name, 'r') as file:
                self.out = file.read()
        else:
            with subprocess.Popen(QuickTest._APP,
                                  stderr=subprocess.PIPE,
                                  stdin=subprocess.PIPE,
                                  stdout=subprocess.PIPE) as proc:
                out, err = proc.communicate(
                    input=QuickTest._INPUT[self.data_idx].encode("utf-8"))

                if err:
                    print("ERROR: " + err)
                    return False

                return_code = proc.returncode

                try:
                    self.out = out.decode("utf-8") if out else None
                except UnicodeDecodeError as decode_err:
                    self.out = "Serious execution badness:" + format(decode_err)

        if return_code != 0:
            print("ERROR: EXPECTED return 0, ACTUAL return {}."
                  .format(return_code), file=sys.stderr)
            return False

        if not self.out:
            print("ERROR: No output from student app.", file=sys.stderr)
            return False

        print("<-----TESTING----->\n")
        print("YOUR PROGRAM parse_scores PRODUCED")
        print("------------------------")
        print(self.out + "------------------------")
        print("WITH: echo '" + QuickTest._INPUT[self.data_idx] + "' | ./parse_scores\n")
        return True


    def __init__(self, index=0, file_name=None):
        """Method documentation goes here.
        """

        self.out = None
        self.student_info = None
        self.file_name = file_name
        self.data_idx = index

        self.run()


    def test_max_score(self):
        """Method documentation goes here.
        """
        if 'max_score' not in self.student_info:
            print("    ERROR: missing max_score in JSON")
            return False

        if self.student_info['max_score'] != QuickTest._MAX_SCORE[self.data_idx]:
            print(
                "    FAILED: EXPECTED max_score {} ACTUAL : {}".format(
                    QuickTest._MAX_SCORE[self.data_idx],
                    self.student_info['max_score']))
            return False

        print("    PASSED: max_score")
        return True


    def test_max_id(self):
        """Method documentation goes here.
        """
        if 'max_id' not in self.student_info:
            print("    ERROR: missing max_id")
            return False

        if self.student_info['max_id'] != QuickTest._MAX_ID[self.data_idx]:
            print(
                "    FAILED: EXPECTED max_id {} ACTUAL : {}".format(
                    QuickTest._MAX_ID[self.data_idx],
                    self.student_info['max_id']))
            return False

        print("    PASSED: max_id")
        return True


    def test_grades(self):
        """Method documentation goes here
        """
        err = "    ERROR: "
        if 'students' not in self.student_info:
            print(err + "Missing students array in JSON")
            return False

        if len(self.student_info['students']) == 0:
            print(err + "Empty students array in JSON")
            return False

        for student in self.student_info['students']:
            if 'id' not in student:
                print(
                    err + "Missing id field for student in students array in JSON")
                return False

            if 'grades' not in student:
                print(
                    err + "Missing grades array in JSON for student id "
                    + str(student['id'])
                )
                return False

            if len(student['grades']) == 0:
                print(
                    err + "Empty grades array in JSON for student id "
                    + str(student['id']))
                return False
            if len(student['grades']) \
                    != len(QuickTest._GRADES[self.data_idx][student['id']]) \
                    or not all(
                            grade in student['grades'] \
                            for grade in QuickTest._GRADES[self.data_idx][student['id']]):
                print(
                    "    FAILED "
                    + "missing or incorrect values in grades array for student id "
                    + str(student['id'])
                )
                print(
                    "        Expected: {}, Actual: {}".format(
                        QuickTest._GRADES[self.data_idx][student['id']],
                        student['grades'])
                )
                return False


        print("    PASSED: grade check")
        return True


    def test(self, test_no):
        """Method documentation goes here
        """
        valid_json = True
        try:
            self.student_info = json.loads(self.out)
        except json.decoder.JSONDecodeError as err:
            # JSON not parsing is a FAILED test when testing parsing and an
            # ERROR when testing any other code aspect.
            valid_json = False

        if test_no == 1: # parse check
            print("TESTING: JSON format:")
            if not valid_json:
                print("    FAILED: JSON is not valid format.")
                return False
            print("    PASSED: JSON is valid format")
            return True

        if not valid_json:
            print("ERROR: JSON decode error. Your JSON is not valid. ABORTING")
            return False

        if test_no == 2: # check max score
            print("TESTING: max_score")
            return self.test_max_score()

        if test_no == 3: # check max id
            print("TESTING: max_id")
            return self.test_max_id()

        if test_no == 4:  # grades check
            print("TESTING: grades for each student")
            return self.test_grades()


if __name__ == "__main__":
    if len(sys.argv) == 1:
        PASSED = True
        for data_idx in [0, 1, 2]:
            TESTER = QuickTest()
            PASSED = all(TESTER.test(test_no) for test_no in [1, 2, 3, 4]) \
                and PASSED
        sys.exit(0 if PASSED else 1)

    elif len(sys.argv) == 2:
        PASSED = True
        for data_idx in [0, 1, 2]:
            TESTER = QuickTest(int(data_idx))
            PASSED = TESTER.test(int(sys.argv[1])) and PASSED
        sys.exit(0 if PASSED else 1)

    elif len(sys.argv) == 3:
        TESTER = QuickTest(int(sys.argv[1]))
        sys.exit(0 if TESTER.test(int(sys.argv[2])) else 1)

    else:
        print("UNRECOGNIZED ARGUMENTS: " + sys.argv)
        sys.exit(-1)
