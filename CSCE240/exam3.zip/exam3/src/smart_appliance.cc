/*Copyright 2021 CSCE 240
*/
#include <exam3/inc/smart_appliance.h>
#include<string>
using std::string;

  exam3::problem3::SmartAppliance::~SmartAppliance() {/* empty */ }
  exam3::problem3::SmartLight::SmartLight() {
    isOn = false;
    isAct = false;
  }
  const std::string exam3::problem3::SmartLight::Activate() {
    if (isAct) {
       isAct = true;
       std::string str = "{\"active\": true, \"previous\": true}";
       return str;
     } else {
       isAct = true;
       std::string str = "{\"active\": true, \"previous\": false}";
       return str;
    }
  }

  const std::string exam3::problem3::SmartLight::Deactivate() {
    if (isAct) {
      isAct = false;
      std::string str = "{\"active\": false, \"previous\": true}";
      return str;
    } else {
      isAct = false;
      std::string str = "{\"active\": false, \"previous\": false}";
      return str;
    }
  }

  const std::string exam3::problem3::SmartLight::Set(unsigned int setting) {
    std::string str;
    if (!isAct) {
      str = "{ \"active\": false }";
      return str;
    }
    if (setting == 1 && !isOn) {
      isOn = true;
      str = "{ \"active\": true, \"on\": true, \"previous\": false }";
      return str;
    }
    if (setting == 1 && isOn) {
      isOn = true;
      str = "{ \"active\": true, \"on\": true, \"previous\": true }";
      return str;
    }
    if (setting == 0 && isOn) {
      isOn = false;
      str = "{ \"active\": true, \"on\": false, \"previous\": true }";
      return str;
    }
    if (setting == 0 && !isOn) {
      isOn = false;
      str = "{ \"active\": true, \"on\": false, \"previous\": false }";
      return str;
    }
    return "";
  }

  exam3::problem3::SmartThermostat::SmartThermostat() {
    temp = "null";
    isAct = false;
  }

  const std::string exam3::problem3::SmartThermostat::Activate() {
    if (isAct) {
      isAct = true;
      std::string str = "{\"active\": true, \"previous\": true}";
      return str;
    } else {
      isAct = true;
      std::string str = "{\"active\": true, \"previous\": false}";
      return str;
    }
  }

  const std::string exam3::problem3::SmartThermostat::Deactivate() {
    if (isAct) {
      isAct = false;
      std::string str = "{\"active\": false, \"previous\": true}";
      return str;
    } else {
      isAct = false;
      std::string str = "{\"active\": false, \"previous\": false}";
      return str;
    }
  }

  const std::string exam3::problem3::SmartThermostat::Set
        (unsigned int setting) {
    std::string str;
    if (!isAct) {
      str = "{ \"active\": false }";
      return str;
    }
    int buftem = static_cast<int>(50*setting*0.01+40+0.5);
    if (temp =="null") {
      temp = std::to_string(buftem);
      str = "{ \"active\": true, \"temp\": "+temp+", \"previous\": null }";
      return str;
    } else {
      str = "{ \"active\": true, \"temp\": "
      +std::to_string(buftem)+", \"previous\": "+temp+" }";
      temp = std::to_string(buftem);
      return str;
    }
  }





