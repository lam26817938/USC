/*Copyright 2021 CSCE 240
*/
#include <exam3/inc/tight_vector.h>


TightVector::TightVector() {
  count_ = 0;
}

TightVector::~TightVector() {
  if (array_)
  delete [] array_;
}

void TightVector::Append(int element) {
  if (count_ == 0) {
    array_ = new int[1];
    array_[0] = element;
  } else {
    int *arr_ = array_;
    array_ = new int[count_+1];
    for (size_t i = 0; i < count_; i++) {
       array_[i] = arr_[i];
    }
    array_[count_] = element;
    delete [] arr_;
  }
  count_++;
}

void TightVector::Prepend(int element) {
  if (count_ == 0) {
    array_ = new int[1];
    array_[0] = element;
  } else {
    int *arr_ = array_;
    array_ = new int[count_+1];
    array_[0] = element;
    for (size_t i = 1; i < count_; i++) {
       array_[i] = arr_[i-1];
    }
    delete [] arr_;
  }
  count_++;
}

