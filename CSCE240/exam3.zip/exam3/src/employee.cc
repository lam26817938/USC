/*Copyright 2021 CSCE 240
*/
#include <exam3/inc/employee.h>

/*exam3::problem2::Demographic() {
  first_name_ = "First";
  last_name_ = "Last";
  date_of_birth_ = "6/18/2021"; 
}
*/

/*exam3::problem2::Employee::Employee() {
  first_name_ = Demographic.first_name;
  last_name_ = Demographic.last_name;
  date_of_birth_ = Demographic.date_of_birth; 
  employee_id_ = "0000";
}*/

/*double exam3::problem2::Employee::pay_rate() const {
  inline double pay_rate;
  return pay_rate;
}

double exam3::problem2::Employee::double CalculatePay(double) const {
  double Hours_worked;  
  CalculatePay = pay_rate*Hours_worked;
  return CalculatePay
}
*/
exam3::problem2::Demographic::Demographic(const std::string& first_name,
              const std::string& last_name,
              const std::string& date_of_birth) {
  first_name_ = first_name;
  last_name_ = last_name;
  date_of_birth_ = date_of_birth;
}

const std::string exam3::problem2::Demographic::first_name() const {
  return first_name_;
}
  const std::string exam3::problem2::Demographic::last_name() const {
  return last_name_;
}
  const std::string exam3::problem2::Demographic::date_of_birth() const {
  return date_of_birth_;
}

exam3::problem2::Employee::Employee(
           const std::string& first_name,
           const std::string& last_name,
           const std::string& date_of_birth,
           const std::string& employee_id):Demographic
           (last_name, last_name, date_of_birth) {
  employee_id_ = employee_id;
}

const std::string exam3::problem2::Employee::employee_id() const {
  return employee_id_;
}

exam3::problem2::HourlyEmployee::HourlyEmployee
                (const std::string& first_name,
                 const std::string& last_name,
                 const std::string& date_of_birth,
                 const std::string& employee_id,
                 double hourly_rate): Employee
                 (last_name, last_name, date_of_birth, employee_id) {
  pay_rate_ = hourly_rate;
}

double exam3::problem2::HourlyEmployee::pay_rate() const {
  return pay_rate_;
}

double exam3::problem2::HourlyEmployee::CalculatePay
       (double hours_worked) const {
  double outp = pay_rate_*hours_worked;
  return outp;
}

exam3::problem2::SalaryEmployee::SalaryEmployee(const std::string& first_name,
                 const std::string& last_name,
                 const std::string& date_of_birth,
                 const std::string& employee_id,
                 double salary):Employee
                 (last_name, last_name, date_of_birth, employee_id) {
  pay_rate_ = salary;
}

double exam3::problem2::SalaryEmployee::pay_rate() const {
  return pay_rate_;
}

double exam3::problem2::SalaryEmployee::CalculatePay
       (double annual_percentage) const {
  double outp = pay_rate_*annual_percentage*0.01;
  return outp;
}

