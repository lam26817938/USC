/* Copyright 2021 CSCE 240
*/

#include <exam3/inc/char_matrix.h>



/*CharMatrix::CharMatrix() { 
  
  matrix_[][] = chars[rows_][cols_];
  }*/
CharMatrix::CharMatrix(const char** chars, ::size_t rows, ::size_t cols) {
  rows_ = rows;
  cols_ = cols;
  matrix_ = new char*[rows];
  for (::size_t i = 0; i < rows; i++) {
    matrix_[i] = new char[cols];
    for (::size_t j = 0; j < cols; j++) {
      matrix_[i][j] = chars[i][j];
    }
  }
}

CharMatrix::CharMatrix(const CharMatrix& that) {
  rows_ = that.rows();
  cols_ = that.cols();
  matrix_ = new char*[that.rows()];
  for (::size_t i = 0; i < that.rows(); i++) {
      matrix_[i] = new char[that.cols()];
      for (::size_t j = 0; j< that.cols(); j++) {
        matrix_[i][j] = that.matrix()[i][j];
    }
  }
}

CharMatrix::~CharMatrix() {
  for (size_t p = 0; p < rows_; p++) {
    delete [] matrix_[p];
  }
  delete [] matrix_;
}

const CharMatrix& CharMatrix::operator=(const CharMatrix& rhs) {
  rows_ = rhs.rows();
  cols_ = rhs.cols();
  matrix_ = new char*[rhs.rows()];
  for (::size_t i = 0; i < rhs.rows(); i++) {
      matrix_[i] = new char[rhs.cols()];
      for (::size_t j = 0; j< rhs.cols(); j++) {
        matrix_[i][j] = rhs.matrix()[i][j];
      }
  }
  return *this;
}




















