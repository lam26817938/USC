// Copyright 2022 Lian Liao

#include <hw5/inc/rational.h>

using csce240::hw5::Rational;

Rational::Rational() {
  num_ = 0;
  den_ = 1;
}
Rational::Rational(int num) {
  num_ = num;
  den_ = 1;
}
Rational::Rational(int num, int den) {
  num_ = num;
  den_ = den;
  if (den_ < 0) {
    den_ = -den_;
    num_ = -num_;
  }
}
  int Rational::num() const {
     return num_;
  }
  int Rational::den() const {
     return den_;
  }

  int Rational::GCD(int a, int b) const {
    while (a != b) {
      if (a > b) {
        a -= b;
      } else {
        b -= a;
      }
    }
    return a;
  }

  double Rational::ToDouble() const {
    double dpoints = (1.0*num_)/(1.0*den_);
    return dpoints;
  }

  std::string Rational::ToString() const {
    if (num_ == 0 && den_ != 0) {
      return "0";
    } else {
      return std::to_string(num_) + "/" + std::to_string(den_);
    }
  }

  const bool Rational::Equals(const Rational& rhs) const {
    int tempnumlhs = num_*rhs.den_;
    int tempnumrhs = rhs.num_*den_;
    if (tempnumlhs == tempnumrhs)
      return true;
    else
      return false;
  }
  const bool Rational::operator==(const Rational& rhs) const {
       return Equals(rhs);
  }

  const bool Rational::Equals(int rhs) const {
    int temps = num_/den_;
      if (temps == rhs)
        return true;
      else
        return false;
  }

  const bool Rational::operator==(int rhs) const {
     return Equals(rhs);
  }

  const Rational Rational::DividedBy(const Rational& rhs) const {
    int tempnum = num_*rhs.den_;
    int tempden = rhs.num_*den_;
    int k = Rational::GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return Rational(tempnum, tempden);
  }

  const Rational Rational::operator/(const Rational& rhs) const {
    return DividedBy(rhs);
  }

  const Rational Rational::DividedBy(int rhs) const {
    int tempnum = num_;
    int tempden = den_*rhs;
    return Rational(tempnum, tempden);
  }
  const Rational Rational::operator/(int rhs) const {
    return DividedBy(rhs);
  }

  const Rational Rational::Plus(const Rational& rhs) const {
    int tempnum = num_*rhs.den_+den_*rhs.num_;
    int tempden = rhs.den_*den_;
    int k = Rational::GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return Rational(tempnum, tempden);
  }

  const Rational Rational::operator+(const Rational& rhs) const {
       return Plus(rhs);
  }

  const Rational Rational::Plus(int rhs) const {
    int tempnum = num_+den_*rhs;
    int tempden = den_;
    int k = csce240::hw5::Rational::GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return Rational(tempnum, den_);
  }

  const Rational Rational::operator+(int rhs) const {
    return Plus(rhs);
  }

  bool const csce240::hw5::operator==(int lhs, const Rational& rhs) {
    return rhs.operator==(lhs);
  }

  const Rational csce240::hw5::operator/(int lhs, const Rational& rhs) {
        Rational x = rhs.operator/(lhs);
        return Rational(x.den(), x.num());
  }

  const Rational csce240::hw5::operator+(int lhs, const Rational& rhs) {
    return rhs.operator + (lhs);
  }
