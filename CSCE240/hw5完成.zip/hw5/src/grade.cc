//  Copyright 2022 Lian Liao

#include <hw5/inc/grade.h>

using csce240::hw5::Grade;

Grade::Grade() {
  scored_ = 0;
  total_ = 1;
}

Grade::Grade(unsigned int scored, unsigned int total)
             :Rational(scored, total) {
  scored_ = scored;
  total_ = total;
}
unsigned int Grade::scored() const {
  return scored_;
}
unsigned int Grade::total() const {
  return total_;
}

double Grade::ToDouble(unsigned int precision) const {
    double dPoints =  (static_cast<int>((1.0*scored_)/(1.0*total_)
                      *pow(10, precision+3)+5)/10)/pow(10, precision);
    return dPoints;
  }
double Grade::ToDouble() const  {
    double dPoints = (static_cast<int>((1.0*scored_)/(1.0*total_)
                      *pow(10, 6)+5)/10)/pow(10, 3);
    return dPoints;
}

std::string Grade::ToString() const {
      return std::to_string(scored_) + "/" + std::to_string(total_);
  }

  const bool Grade::operator==(const Grade& rhs) const {
    int tempscoredlhs = scored_*rhs.total_;
    int tempscoredrhs = rhs.scored_*total_;
    if (tempscoredlhs == tempscoredrhs)
      return true;
    else
      return false;
  }

  const bool Grade::operator==(int rhs) const {
    int temps = scored_/total_;
    if ( temps == rhs)
      return true;
    else
      return false;
  }

  const bool csce240::hw5::operator==(int lhs, const Grade& rhs) {
      return rhs.operator == (lhs);
  }
