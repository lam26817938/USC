// Copyright 2022 Lian

#include <hw3/inc/find_sum.h>
#include <hw3/inc/find_sum.h>

#include <cstddef>  // size_t
#include <iostream>
#include <fstream>

const size_t** FindSum(const int** matrix,
                       const size_t* matrix_size,
                       int search_sum,
                       size_t* sums_found) {
  *sums_found = 0;
  const size_t row = matrix_size[0];
  const size_t col = matrix_size[1];
  size_t countSum;
  int counter;
  size_t check = -87;
  size_t **temp = new size_t *[9999999];
  for (size_t i =0; i < 9999999; ++i) {
    temp[i] = new size_t[4];
  }
  temp[0][0] = check;

    // ColSummation
    for (size_t j = 0; j < col; j++) {
    for (size_t i = 0; i < row; i++) {
      counter = 0;
      for (size_t k = i; k < row; k++) {
             counter += matrix[k][j];
        if (counter == search_sum) {
          size_t indices[] = {i, j, k, j};
          countSum = 0;
          while (countSum < 4) {
          temp[*sums_found][countSum] = indices[countSum];
          countSum++;
          }
          (*sums_found)++;
          }
        }
      }
    }

    // RowSummation
    for (size_t i = 0; i < row; i++) {
    for (size_t j = 0; j < col; j++) {
      counter = matrix[i][j];
      for (size_t k = j+1; k < col; k++) {
             counter += matrix[i][k];
        if (counter == search_sum) {
          size_t indices[] = {i, j, i, k};
          countSum = 0;
          while (countSum < 4) {
          temp[*sums_found][countSum] = indices[countSum];
          countSum++;
              }
          (*sums_found)++;
          }
        }
      }
    }

    // AscDiaSummation
    for (size_t i = 1; i < row; i++) {
          for (size_t j = 0; j < col; j++) {
          counter = matrix[i][j];
             for (size_t k = 1; k < row ; k++) {
                      if ((i-k < row && i-k >= 0 && j+k < col)) {
                            counter += matrix[i-k][k+j];
                            if (counter == search_sum) {
                               size_t indices[] = {i, j, i-k, j+k};
                               countSum = 0;
                               while (countSum < 4) {
                        temp[*sums_found][countSum] = indices[countSum];
                                  countSum++;
                               }
                              (*sums_found)++;
                            }
                    }
              }
         }
       }

    // DesDiaSummation
    for (size_t i = 0; i < row; i++) {
          for (size_t j = 0; j < col; j++) {
          counter = matrix[i][j];
             for (size_t k = 1; k < row ; k++) {
                      if ((i+k < row && j+k < col)) {
                               counter += matrix[i+k][k+j];
                               if (counter == search_sum) {
                               size_t indices[] = {i, j, i+k, j+k};
                               countSum = 0;
                               while (countSum < 4) {
                        temp[*sums_found][countSum] = indices[countSum];
                                  countSum++;
                               }
                            (*sums_found)++;
                        }
                    }
              }
         }
       }

    // answer
    if (temp[0][0] != check) {
    size_t **answer = new size_t *[*sums_found];
    for (size_t p = 0; p < *sums_found; ++p) {
    answer[p] = new size_t[4];
    for (size_t q = 0; q < 4; ++q) {
      answer[p][q] = temp[p][q];
    }
  }
    for (size_t i = 0; i < 9999999; ++i)
        delete [] temp[i];
    delete [] temp;

           return const_cast<const size_t**>(answer);
    }
    for (size_t i = 0; i < 9999999; ++i)
          delete [] temp[i];
    delete [] temp;

      return nullptr;
}
