// Copyright 2022 <Lian>

#include <exam1/problem3.h>
#include <exam1/problem3.h>

#include <string>
#include <iostream>
#include <fstream>
#include <climits>
using std::ostream;
using std::string;

double Max(const string& name) {
  std::ifstream fin;
  fin.open(name);
  double max = INT_MIN;
  int d_num;
  fin >> d_num;
  double num;
  for (int i = 0; i < d_num; i++) {
    fin >> num;
    if (num > max) {
      max = num;
    }
  }
  return max;
}

double Min(const string& name) {
  std::ifstream fin;
  fin.open(name);
  double min = INT_MAX;
  int d_num;
  fin >> d_num;
  double num;
  for (int i = 0; i < d_num; i++) {
    fin >> num;
    if (num < min) {
      min = num;
    }
  }
  return min;
}

double Sum(const string& name) {
  std::ifstream fin;
  fin.open(name);
  int d_num;
  double sum = 0;
  fin >> d_num;
  double num;
  for (int i = 0; i < d_num; i++) {
      fin >> num;
      sum += num;
  }
  return sum;
}

double Avg(const string& name) {
  std::ifstream fin;
  fin.open(name);
  int d_num;
  double sum = 0;
  fin >> d_num;
  double num;
  for (int i = 0; i < d_num; i++) {
      fin >> num;
      sum += num;
  }
  return sum/d_num;
}


void Sort(const string& name, double arr[]) {
  std::ifstream fin;
  fin.open(name);
  int d_num;
  fin >> d_num;
  double num;
  for (int i = 0; i < d_num; i++) {
      fin >> num;
      arr[i] = num;
  }
  for (int i = 0; i < d_num - 1; i++) {
      for (int j = 0; j < d_num-1-i; j++) {
          if (arr[j+1] < arr[j]) {
              double t = arr[j];
              arr[j] = arr[j+1];
              arr[j+1] = t;
          }
      }
  }
  }
