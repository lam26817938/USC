// Copyright 2022 <Lian>

#include <exam1/problem2.h>
#include <exam1/problem2.h>

#include <string>
#include <iostream>
using std::string;
std::string SumDigits(const std::string& value) {
try {
  int sum = 0;
  int input = std::stoi(value);
  if (input < 0) {
    while (input < 0) {
          int digit = -input % 10;
          input /= 10;
          sum += (-digit);
    }
  } else {
      while (input > 0) {
        int digit = input % 10;
        input /= 10;
        sum += digit;
      }
  }
  string re = std::to_string(sum);
  return re;
}catch (const std::invalid_argument& exception) {
       return "";
}
}
