/*copyright 2021 CSCE240 
*/


#include <exam1/problem5.h>
#include <exam1/problem5.h>

using std::ostream;
using std::string;

int Max(string file_name) {
  std::ifstream fin;
  fin.open(file_name);
  string line;
  int max = INT_MIN;
  string word ="";
  int int_num;
  fin >> int_num;
  int num;
  for (int i = 0; i < int_num; i++) {
    fin >> num;
    if (num > max) {
      max = num;
    }
  }
  return max;
}

int Min(string file_name) {
  std::ifstream fin;
  fin.open(file_name);
  string line;
  int min = INT_MAX;
  string word ="";
  int int_num;
  fin >> int_num;
  int num;
  for (int i = 0; i < int_num; i++) {
    fin >> num;
    if (num < min) {
      min = num;
    }
  }
  return min;
}

int Sum(string file_name) {
  std::ifstream fin;
  fin.open(file_name);
  string line;
  string word ="";
  int int_num;
  int sum = 0;
  fin >> int_num;
  int num;
  for (int i = 0; i < int_num; i++) {
      fin >> num;
      sum += num;
  }
  return sum;
}

double Avg(string file_name) {
  std::ifstream fin;
  fin.open(file_name);
  string line;
  string word ="";
  int int_num;
  int sum = 0;
  double avg = 0.0;
  fin >> int_num;
  int num;
  for (int i = 0; i < int_num; i++) {
      fin >> num;
      sum += num;
  }
  avg = sum/int_num;
  return avg;
}

void swap(int a[], int i, int j) {
  int t = a[i];
  a[i] = a[j];
  a[j] = t;
}

void bubble_sort(int a[], int length) {
  int max = length-1;
  for (int i = 0; i < max; i++) {
      for (int j = 0; j < max-i; j++) {
          if (a[j+1] < a[j]) {
              swap(a, j, j+1);
          }
      }
  }
}

void Sort(string file_name, int input[]) {
  std::ifstream fin;
  fin.open(file_name);
  string line;
  string word ="";
  int int_num;
  fin >> int_num;
  int num;
  for (int i = 0; i < int_num; i++) {
      fin >> num;
      input[i] = num;
  }
  bubble_sort(input, int_num);
}
