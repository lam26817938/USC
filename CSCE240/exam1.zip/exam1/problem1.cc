/*Copyright 2021 CSCE 240
*/

/* Problem1: postfix notation arithmetic calculator
 *
 *  We customarily write arithmetic in infix notation, e.g. 1.0 + 2.0.  In this
 *  assignment you are creating a postfix notation calculator e.g. 1.0 2.0 -
 *
 *  The program must read the operands and operator from the standard input
 *  stream (using cin). Input on the stream will always consist of a
 *  3-tuple---the left and right operands will be first and second; the
 *  operator will be third (see above). You must print the result of the
 *  operation to the standard output stream (using cout).
 *
 *  DO NOT emit anything other than the result. This is a calculator. Simply
 *  emit the result of the operation. Do not prompt for input. Just write the
 *  result of the operation to STDOUT using cout.
 *
 *  You must provide operators:
 *    + : addition
 *    - : subtraction
 *    x : multiplication
 *    / : division
 *    < : less than
 *    > : greater than
 *
 * Notes:
 *  The two operands should be read as floating point data and the operator can
 *  be read as a character or string. You need not set precision for the
 *  floating point output. The default precision for a double is all that is
 *  required.
 *
 * Points:
 *  compilation: 1
 *  style: 1
 *  correctness: 1
 */

#include <iostream>
using std::cin;
using std::cout;
using std::endl;
using std::ostream;

int main() {
  double num_1;
  double num_2;
  char op;
  cin >> num_1;
  cin >> num_2;
  cin >> op;

  switch(op) {
    case '+':
      cout << num_1+num_2 << endl;
        break;

    case '-':
      cout << num_1-num_2 << endl;
        break;

    case 'x':
      cout << num_1*num_2 << endl;
        break;

    case '/':
      if (num_2 == 0) {
        break;
      } else {
        cout << num_1/num_2 << endl;
         break;
      }

    case '<':
      if (num_1 < num_2) {
        cout << "true" << endl;
          break;
      } else {
        cout << "false" << endl;
          break;
      }

    case '>':
      if (num_1 > num_2) {
        cout << "true" << endl;
          break;
      } else {
        cout << "false" << endl;
          break;
      }
  return 0;
  }
}
