/* Copyright 2021 CSCE 240 */

#include <exam1/problem4.h>
#include <exam1/problem4.h>  // test correct header constuction

#include <cassert>
#include <cstddef>
#include <iostream>
#include <string>

int main(int argc, char* argv[]) {
  std::cout << "Problem 4" << std::endl;
  assert(kTestVal == 'B');  // test correct header construction

  const unsigned int kValues[] = { 3, 5, 13, 21, 69, 201, 6023 };
  const std::string kExpected_binary[] = {
    "00000011",
    "00000101",
    "00001101",
    "00010101",
    "01000101",
    "11001001",
    "10000111"
  };

  for (size_t i = 0; i < sizeof(kValues)/sizeof(int); ++i) {
    std::cout << "  DecimalToBinary(" << kValues[i] << ")" << std::endl;

    std::cout << "    Expected: " << kExpected_binary[i] << ", Actual: "
      << DecimalToBinary(kValues[i]) << std::endl;
  }

  return 0;
}
