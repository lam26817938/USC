/*copyright CSCE 2021
*/

/* Problem2: postfix notation arithmetic calculator
 * Arithmetic is customarily represented using infix notation, e.g. 1 + 2. In
 * this assignment, you are creating a postfix notation calculator,
 * e.g. 1 2 +.
 * 
 * Read the three arguments passed into the file. They will be at indices 1, 2,
 * and 3. The left and right operands at indices 1 and 2, respectively, and the
 * operator will be at index 3. You will write the output of the operation to
 * STDOUT using cout. DO NOT  emit anything else. This is a calculator. Simply
 * write the result of the operation to the standard output stream (using cout).
 * 
 * 
 * You must provide operators:
 *   + : addition
 *   - : subtraction
 *   x : multiplication
 *   / : division
 *   % : modulo
 *   \^ : exponentiation
 * 
 * \subsection*{Notes:}
 * The two operands should be converted to integral data and the operator is a
 * character or string. The arguments are passed in as character arrays (char*
 * argv[]) and so the operator cannot be directly compared to string literals
 * such as ``+''.  I would recommend using the string class, which accepts a
 * character array in its constructor and provides the == (equivalency) operator
 * to determine which operator was provided. 
 * 
 * The operands can be converted from character arrays (char* argv[]) to
 * signed ints by the atoi function (not stoi).
 * 
 * References:
 *  atoi: http://www.cplusplus.com/reference/cstdlib/atoi/
 *  string: http://www.cplusplus.com/reference/string/
 * 
 * Points:
 *   compilation: 1
 *   style: 1
 *   correctness: 1
 */

#include <cstddef>
#include <string>
#include <iostream>
#include <stdexcept>
#include <array>
#include <cmath>
#include <cassert>
#include <cstdlib>


using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::string;

int main(int argc, char* argv[]) {
  assert(argc == 3);
  int num_1 = std::atoi(argv[0]);
  int num_2 = std::atoi(argv[1]);
  string op = argv[2];

  if (op == "+") {
    cout << num_1+num_2 << endl;
  } else if (op == "-") {
      cout << num_1-num_2 << endl;
  } else if (op == "x") {
      cout << num_1*num_2 << endl;
  } else if (op == "/") {
      cout << num_1/num_2 << endl;
  } else if (op == "%") {
      cout << num_1%num_2 << endl;
  } else if (op == "^") {
      cout << pow(num_1, num_2) << endl;
  }

return 0;
} 
