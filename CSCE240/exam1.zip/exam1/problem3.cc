/*copyright CSCE 2021
*/

#include <cstddef>
#include <string>
#include <iostream>
#include <stdexcept>
#include <array>
#include <exam1/problem3.h>


using std::string;

int SumDigits(int input) {
  int sum = 0;
  if (input < 0) {
    while (-input > 0) {
          int digit = -input % 10;
          input /= 10;
          sum += (-digit);
    }
  } else {
      while (input > 0) {
        int digit = input % 10;
        input /= 10;
        sum += digit;
      }
  }
  return sum;
}
