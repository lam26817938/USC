/*copyright 2021 CSCE240 
*/

#include <exam1/problem4.h>
#include <exam1/problem4.h>


string DecimalToBinary(int n) {
  int binaryNum[8];
  for (int i = 0; i < 8; i++) {
      binaryNum[i] = 0;
  }
  int i = 0;
  while (n > 0 && i < 8) {
      binaryNum[i] = n%2;
      n = n/2;
      i++;
  } string binary ="";
  for (int j = 7; j >= 0; j--) {
     binary += '0'+binaryNum[j];
  }
  return binary;
}
