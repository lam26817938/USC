/*copyright 2021 CSCE240 
*/

/**File Processing
 *  These set of functions accepts a string file name, opens the file, reads
 *  the contents, and processes the contained data as indicated (excluding the
 *  count of integers).
 *
 *  The file format consists of an integer n, followed by n additional positive
 *  and negative integers. The first value is not part of the dataset. The
 *  values are all separated by white space and so can be parsed using the
 *  insertion operator (>>). You should probably use the fstream object (which
 *  accepts a string in its constructor) to read the integers.
 *
 * Functions:
 * Max: accepts string parameter, returns integer value representing the
 *      largest value of the integers in file
 * Min: accepts string parameter, returns integer value representing the
 *      smallest value of the integers in file
 * Sum: accepts string parameter, returns integer value representing the sum of
 *      the values of the integers in file
 * Avg: accepts string parameter, returns floating point value representing the
 *      sum of the values of the integers in file
 * Sort: accepts a string parameter and an integer array parameter. The integer
 *       array will be large enough to hold all integer values (except count)
 *       in the file; this is a precondition. The function stores the sorted
 *       values from the file in the integer array. Note that you may not use
 *       the algorithm library.  Any student doing so will receive 0/6 for
 *       this problem.
 *
 * References:
 *  fstream: http://cplusplus.com/reference/fstream/
 *  string: http://cplusplus.com/reference/string/
 *
 * Points:
 *  -compilation: 1
 *  -style: 1
 *  -correctness: 4 (Max: 0.5, Min: 0.5, Sum: 0.5, Avg: 1, Sort: 1.5)
 */
 

#ifndef PROBLEM5_H_
#define PROBLEM5_H_

#define _GLIBCXX_ALGORITHM -1

#include <string>
#include <iostream>
#include <fstream>
#include <climits>
#include <utility>

using std::ostream;
using std::string;


const char kTestVal = 'C';  // used to test correct header construction

int Max(string file_name);

int Min(string file_name);

double Avg(string file_name);

int Sum(string file_name);

void swap(int a[], int i, int j);

void bubble_sort(int a[], int length);

void Sort(string file_name, int input[]);

#endif  //  PROBLEM5_H_ 
