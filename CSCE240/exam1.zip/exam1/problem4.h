/*copyright 2021 CSCE240 
*/


/* DecimalToBinary
 *  Accepts an unsigned integer value and returns the 8-bit binary
 *  representation of that number as a string. For example, 3 returns the
 *  string "00000011", 5 returns the string "00000101", and 17 returns
 *  "00010001". If
 *  a value which cannot be stored in 8-bit binary is received, only store the
 *  right-most eight bits, e.g. 6023 returns the string "10000111".
 *
 *  A simple algorithm you might use is as follows:
 *   (1) Begin with an empty string.
 *   (2) Divide decimal value by 2. If there is a remainder, add a "0" to the
 *       beginning of the string or a "1" if not.
 *   (3) Reduce the decimal value by half, taking its floor, i.e.
 *       floor(5 / 2) = 2. Note this is the behavior of integer arithmetic.
 *   (4) Repeat steps 2 and 3 until the decimal value is 0.
 *
 * I will leave it to you to consider solutions to ensure width (8-bit).
 *
 * References:
 *  string: http://cplusplus.com/reference/string/
 *
 * Points:
 *  -compilation: 1
 *  -style: 1
 *  -correctness: 3
 */


#ifndef PROBLEM4_H_
#define PROBLEM4_H_
#include <cassert>
#include <cstddef>
#include <iostream>
#include <string>

using std::string;

const char kTestVal = 'B';  // used to test correct header construction

string DecimalToBinary(int n);

#endif  //  PROBLEM4_H_ 
