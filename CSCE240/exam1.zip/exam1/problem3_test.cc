/* Copyright 2021 CSCE 240 */

#include <exam1/problem3.h>
#include <exam1/problem3.h>  // check correct header construction

#include <cassert>
// assert
#include <cstddef>
// size_t
#include <iostream>


int main(int argc, char* argv[]) {
  std::cout << "Problem 3" << std::endl;

  assert(kTestVal == 'A');  // check correct header construction

  int values[] = { 813546, -7613 };
  int expected[] = { 27, -17 };

  for (size_t i = 0; i < sizeof(values)/sizeof(int); ++i) {
    std::cout << "  SumDigits(" << values[i] << ")" << std::endl;

    std::cout << "    Expected: " << expected[i] << ", Actual: "
      << SumDigits(values[i]) << std::endl;
  }

  return 0;
}
