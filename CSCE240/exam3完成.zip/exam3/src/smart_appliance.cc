// Copyright Lian

#include<exam3/inc/smart_appliance.h>
#include<string>

using std::string;
using exam3::problem3::SmartLight;
using exam3::problem3::SmartThermostat;
using exam3::problem3::SmartAppliance;

  SmartAppliance::~SmartAppliance() {}

  SmartLight::SmartLight() {
    isOn = false;
    isAct = false;
  }

  const string SmartLight::Activate() {
    if (isAct) {
       string ans = "{\"active\": true, \"previous\": true}";
       return ans;
     } else {
       isAct = true;
       string ans = "{\"active\": true, \"previous\": false}";
       return ans;
    }
  }

  const string SmartLight::Deactivate() {
    if (isAct) {
      isAct = false;
      string ans = "{\"active\": false, \"previous\": true}";
      return ans;
    } else {
      string ans = "{\"active\": false, \"previous\": false}";
      return ans;
    }
  }

  const string SmartLight::Set(unsigned int setting) {
    string ans;
    if (!isAct) {
      ans = "{ \"active\": false }";
      return ans;
    }
    if (setting == 1 && !isOn) {
      isOn = true;
      ans = "{ \"active\": true, \"on\": true, \"previous\": false }";
      return ans;
    }
    if (setting == 1 && isOn) {
      ans = "{ \"active\": true, \"on\": true, \"previous\": true }";
      return ans;
    }
    if (setting == 0 && isOn) {
      ans = "{ \"active\": true, \"on\": false, \"previous\": true }";
      return ans;
    }
    if (setting == 0 && !isOn) {
      isOn = false;
      ans = "{ \"active\": true, \"on\": false, \"previous\": false }";
      return ans;
    }
    return "";
  }

  SmartThermostat::SmartThermostat() {
    temp = "null";
    isAct = false;
  }

  const string SmartThermostat::Activate() {
    if (isAct) {
      string ans = "{\"active\": true, \"previous\": true}";
      return ans;
    } else {
      isAct = true;
      string ans = "{\"active\": true, \"previous\": false}";
      return ans;
    }
  }

  const string SmartThermostat::Deactivate() {
    if (isAct) {
      isAct = false;
      string ans = "{\"active\": false, \"previous\": true}";
      return ans;
    } else {
      string ans = "{\"active\": false, \"previous\": false}";
      return ans;
    }
  }

  const string SmartThermostat::Set(unsigned int setting) {
    string ans;
    if (!isAct) {
      ans = "{ \"active\": false }";
      return ans;
    }
    int buftem = static_cast<int>(50*setting*0.01+40+0.5);
    if (temp =="null") {
      temp = std::to_string(buftem);
      ans = "{ \"active\": true, \"temp\": "+temp+", \"previous\": null }";
      return ans;
    } else {
      ans = "{ \"active\": true, \"temp\": "+
              std::to_string(buftem)+", \"previous\": "+temp+" }";
      temp = std::to_string(buftem);
      return ans;
    }
  }
