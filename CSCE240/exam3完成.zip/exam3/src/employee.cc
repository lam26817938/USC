// Copyright Lian

#include <exam3/inc/employee.h>

using exam3::problem2::Demographic;
using exam3::problem2::Employee;
using exam3::problem2::HourlyEmployee;
using exam3::problem2::SalaryEmployee;
using std::string;

Demographic::Demographic(const string& first_name,
              const string& last_name,
              const string& date_of_birth) {
  first_name_ = first_name;
  last_name_ = last_name;
  date_of_birth_ = date_of_birth;
}

const string Demographic::first_name() const {
  return first_name_;
}
const string Demographic::last_name() const {
  return last_name_;
}
const string Demographic::date_of_birth() const {
  return date_of_birth_;
}

Employee::Employee(
           const string& first_name,
           const string& last_name,
           const string& date_of_birth,
           const string& employee_id):Demographic
           (first_name, last_name, date_of_birth) {
  employee_id_ = employee_id;
}

const string Employee::employee_id() const {
  return employee_id_;
}

HourlyEmployee::HourlyEmployee
                (const string& first_name,
                 const string& last_name,
                 const string& date_of_birth,
                 const string& employee_id,
                 double hourly_rate): Employee
                 (first_name, last_name, date_of_birth, employee_id) {
  pay_rate_ = hourly_rate;
}

double HourlyEmployee::pay_rate() const {
  return pay_rate_;
}

double HourlyEmployee::CalculatePay(double hours_worked) const {
  return pay_rate_*hours_worked;
}

SalaryEmployee::SalaryEmployee(const string& first_name,
                 const string& last_name,
                 const string& date_of_birth,
                 const string& employee_id,
                 double salary):Employee
                 (first_name, last_name, date_of_birth, employee_id) {
  pay_rate_ = salary;
}

double SalaryEmployee::pay_rate() const {
  return pay_rate_;
}

double SalaryEmployee::CalculatePay(double annual_percentage) const {
  return pay_rate_*annual_percentage*0.01;
}

