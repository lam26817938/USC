// Copyright Lian

#include <exam3/inc/tight_vector.h>

TightVector::TightVector() {
  count_ = 0;
}

TightVector::~TightVector() {
  if (array_)
     delete [] array_;
}

void TightVector::Append(int element) {
  if (count_ == 0) {
    array_ = new int[1];
    array_[0] = element;
  } else {
    int *temp = array_;
    array_ = new int[count_+1];
    for (size_t i = 0; i < count_; i++) {
       array_[i] = temp[i];
    }
    array_[count_] = element;
    delete [] temp;
  }
  count_++;
}

void TightVector::Prepend(int element) {
  if (count_ == 0) {
    array_ = new int[1];
    array_[0] = element;
  } else {
    int *temp = array_;
    array_ = new int[count_+1];
    array_[0] = element;
    for (size_t i = 0; i < count_; i++) {
       array_[i+1] = temp[i];
    }
    delete [] temp;
  }
  count_++;
}
