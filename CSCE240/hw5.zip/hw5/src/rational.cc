/*Copyright 2021 CSCE 240
*/

#include <hw5/inc/rational.h>
#include <cassert>
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <string>
#include <sstream>

using std::istream;
using std::ostream;
using std::string;

csce240::hw5::Rational::Rational() {
  num_ = 0;
  den_ = 1;
}
csce240::hw5::Rational::Rational(int num) {
  num_ = num;
  den_ = 1;
}
csce240::hw5::Rational::Rational(int num, int den) {
  num_ = num;
  den_ = den;
  if (den_ < 0) {
    den_ = -den_;
    num_ = -num_;
  }
}

  int csce240::hw5::Rational::GCD(int a, int b) const {
    while (a != b) {
      if (a > b) {
        a -= b;
      } else {
        b -= a;
      }
    }
    return a;
  }

  double csce240::hw5::Rational::ToDouble() const {
    double dpoints = (1.0*num_)/(1.0*den_);
    return dpoints;
  }

  string csce240::hw5::Rational::ToString() const {
    if (num_ == 0 && den_ != 0) {
      return "0";
    } else {
      return std::to_string(num_) + "/" + std::to_string(den_);
    }
  }


  const bool csce240::hw5::Rational::Equals
             (const csce240::hw5::Rational& rhs) const {
    int tempnumlhs = num_*rhs.den_;
    int tempnumrhs = rhs.num_*den_;
    if (tempnumlhs == tempnumrhs)
      return true;
    else
      return false;
  }
  const bool csce240::hw5::Rational::operator==
             (const csce240::hw5::Rational& rhs) const {
    int tempnumlhs = num_*rhs.den_;
    int tempnumrhs = rhs.num_*den_;
    if (tempnumlhs == tempnumrhs)
      return true;
    else
      return false;
  }

  const bool csce240::hw5::Rational::Equals(int rhs) const {
    int temps = num_/den_;
      if (temps == rhs)
        return true;
      else
        return false;
  }

  const bool csce240::hw5::Rational::operator==(int rhs) const {
    int temps = num_/den_;
    if (temps == rhs)
      return true;
    else
      return false;
  }

  const csce240::hw5::Rational csce240::hw5::Rational::DividedBy
        (const csce240::hw5::Rational& rhs) const {
    int tempnum = num_*rhs.den_;
    int tempden = rhs.num_*den_;
    int k = csce240::hw5::Rational::GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return csce240::hw5::Rational(tempnum, tempden);
  }

  const csce240::hw5::Rational csce240::hw5::Rational::operator/
                              (const csce240::hw5::Rational& rhs) const {
    int tempnum = num_*rhs.den_;
    int tempden = rhs.num_*den_;
    int k = csce240::hw5::Rational::GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return csce240::hw5::Rational(tempnum, tempden);
  }

  const csce240::hw5::Rational csce240::hw5::Rational::DividedBy
                               (int rhs) const {
    int tempnum = num_*1;
    int tempden = rhs*den_;
    return csce240::hw5::Rational(tempnum, tempden);
  }
  const csce240::hw5::Rational csce240::hw5::Rational::operator/
                               (int rhs) const {
    int tempnum = num_*1;
    int tempden = rhs*den_;
    return csce240::hw5::Rational(tempnum, tempden);
  }

  const csce240::hw5::Rational csce240::hw5::Rational::Plus
                               (const csce240::hw5::Rational& rhs) const {
    int tempnum = num_*rhs.den_+den_*rhs.num_;
    int tempden = rhs.den_*den_;
    int k = csce240::hw5::Rational::GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return csce240::hw5::Rational(tempnum, tempden);
  }

  const csce240::hw5::Rational csce240::hw5::Rational::operator+
                               (const csce240::hw5::Rational& rhs) const {
    int tempnum = num_*rhs.den_+den_*rhs.num_;
    int tempden = rhs.den_*den_;
    int k = csce240::hw5::Rational::GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return csce240::hw5::Rational(tempnum, tempden);
  }

  const csce240::hw5::Rational csce240::hw5::Rational::Plus(int rhs) const {
    int tempnum = num_+den_*rhs;
    int tempden = den_;
    int k = csce240::hw5::Rational::GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return csce240::hw5::Rational(tempnum, den_);
  }

  const csce240::hw5::Rational csce240::hw5::Rational::operator+
                               (int rhs) const {
    int tempnum = num_+den_*rhs;
    int tempden = den_;
    int k = csce240::hw5::Rational::GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return csce240::hw5::Rational(tempnum, den_);
  }

  bool const csce240::hw5::operator==
             (int lhs, const csce240::hw5::Rational& rhs) {
    int temps = rhs.num()/rhs.den();
      if (temps == lhs)
        return true;
      else
        return false;
  }

  const csce240::hw5::Rational csce240::hw5::operator/
                               (int lhs, const csce240::hw5::Rational& rhs) {
    int tempnum = lhs*rhs.den();
    int tempden = rhs.num();
    return csce240::hw5::Rational(tempnum, tempden);
  }

  const csce240::hw5::Rational csce240::hw5::operator+
                               (int lhs, const csce240::hw5::Rational& rhs) {
    int tempnum = lhs*rhs.den()+rhs.num();
    int tempden = rhs.den();
    int k = rhs.GCD(tempnum, tempden);
    tempnum = tempnum / k;
    tempden = tempden / k;
    return csce240::hw5::Rational(tempnum, tempden);
  }
