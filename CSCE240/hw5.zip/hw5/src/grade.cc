/*Copyright 2021 CSCE 240
*/

#include <hw5/inc/grade.h>

csce240::hw5::Grade::Grade() {
  scored_ = 0;
  total_ = 1;
}

csce240::hw5::Grade::Grade(unsigned int scored, unsigned int total)
                           :Rational(scored, total) {
  scored_ = scored;
  total_ = total;
}


double csce240::hw5::Grade::ToDouble(unsigned int precision) const {
    double dPoints =  (static_cast<int>((1.0*scored_)/(1.0*total_)
                      *pow(10, precision+3)+5)/10)/pow(10, precision);
    return dPoints;
  }
double csce240::hw5::Grade::ToDouble() const  {
    double dPoints = (static_cast<int>((1.0*scored_)/(1.0*total_)
                      *pow(10, 6)+5)/10)/pow(10, 3);
    return dPoints;
}

string csce240::hw5::Grade::ToString() const {
      return std::to_string(scored_) + "/" + std::to_string(total_);
  }

  const bool csce240::hw5::Grade::Equals(const csce240::hw5::Grade& rhs) const {
    int tempscoredlhs = scored_*rhs.total_;
    int tempscoredrhs = rhs.scored_*total_;
    if (tempscoredlhs == tempscoredrhs)
      return true;
    else
      return false;
  }

  const bool csce240::hw5::Grade::operator==
              (const csce240::hw5::Grade& rhs) const {
    int tempscoredlhs = scored_*rhs.total_;
    int tempscoredrhs = rhs.scored_*total_;
    if (tempscoredlhs == tempscoredrhs)
      return true;
    else
      return false;
  }

  const bool csce240::hw5::Grade::Equals(int rhs) const {
    int temps = scored_/total_;
      if ( temps == rhs)
        return true;
      else
        return false;
  }

  const bool csce240::hw5::Grade::operator==(int rhs) const {
    int temps = scored_/total_;
    if ( temps == rhs)
      return true;
    else
      return false;
  }

  const bool csce240::hw5::operator==(int lhs, const csce240::hw5::Grade& rhs) {
    int temps = rhs.scored()/rhs.total();
    if ( temps == lhs)
      return true;
    else
      return false;
  }


