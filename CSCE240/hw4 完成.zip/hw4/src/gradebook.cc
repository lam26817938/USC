//  Copyright 2022 Lian


#include <hw4/inc/gradebook.h>

    GradeBook::GradeBook() {
    }

    void GradeBook::Add(const Grade& element) {
    grades.push_back(element);
    }

    const Grade GradeBook::Get(unsigned int index) const {
    if (grades.size() <= index) {
      return Grade(0, 1);
    } else {
      return *std::next(grades.begin(), index);
    }
  }

    const GradeBook GradeBook::Add(const GradeBook& gb) const {
    GradeBook ngb;
    for (Grade st : grades) {
      ngb.Add(st);
    }
    for (Grade st : gb.grades) {
      ngb.Add(st);
    }
    return ngb;
    }

  const Grade GradeBook::CalcAverage() const {
    unsigned int as = 0;
    unsigned int at = 0;
    if (grades.size() <= 0) {
      return Grade(1, 1);
    } else {
      for (unsigned int i = 0; i < grades.size(); i++) {
       as += (*std::next(grades.begin(), i)).scored();
       at += (*std::next(grades.begin(), i)).total();
      }
      return Grade(as, at);
    }
  }
