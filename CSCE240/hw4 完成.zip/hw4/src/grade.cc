// Copyright 2022 Lian

#include <hw4/inc/grade.h>

Grade::Grade() {
  scored_ = 0;
  total_ = 1;
}

Grade::Grade(unsigned int scored, unsigned int total) {
  scored_ = scored;
  total_ = total;
}

unsigned int Grade::scored() const {
        return scored_;
}

unsigned int Grade::total() const {
        return total_;
}

  double Grade::ToDouble() const {
    double dp = round((1.0*scored_)/(1.0*total_)
                              *pow(10, 5))/pow(10, 3);
    return dp;
  }
  double Grade::ToDouble(unsigned int precision) const {
    double dp = round((1.0*scored_)/(1.0*total_)
                              *pow(10, precision+2))/pow(10, precision);
    return dp;
  }

std::string Grade::ToString() const {
    if (scored_ == 0 && total_ != 0) {
      return "0";
    } else {
      return std::to_string(scored_) + "/" + std::to_string(total_);
    }
  }

std::string Grade::ToLetter() const {
    double temp = (1.0*scored_)/(1.0*total_)*100;
    if (temp >= 90) {
      return std::string("A");
    } else if (temp >= 80 && temp < 90) {
      return std::string("B");
    } else if (temp >= 70 && temp < 80) {
      return std::string("C");
    } else if (temp >= 60 && temp < 70) {
      return std::string("D");
    } else {
      return std::string("F");
    }
  }
std::string Grade::ToLetter(unsigned int t) const {
    double temp = (1.0*scored_)/(1.0*total_)*100;
    if (temp >= 100)
      return std::string("A+");
    double temp1 = floor(temp/10)*10;
    bool plus = false;
    if ((temp-temp1)*10 >=t) {
      plus = true;
    }
    if (temp >= 90) {
      return std::string("A")+(plus ? "+" : "");
    } else if (temp >= 80 && temp < 90) {
      return std::string("B") + (plus ? "+" : "");
    } else if (temp >= 70 && temp < 80) {
      return std::string("C") + (plus ? "+" : "");
    } else if (temp >= 60 && temp < 70) {
      return std::string("D") + (plus ? "+" : "");
    } else {
      return std::string("F");
    }
  }

  bool Grade::Equals(const Grade& rhs) const {
    unsigned int tscoredlhs = scored_*rhs.total_;
    unsigned int tscoredrhs = rhs.scored_*total_;
    if ( tscoredlhs == tscoredrhs)
      return true;
    else
      return false;
  }

  Grade Grade::DividedBy(const Grade& rhs) const {
    unsigned int tscored = scored_*rhs.total_;
    unsigned int ttotal = rhs.scored_*total_;
    unsigned int up = 0;
    unsigned int down = 0;
    if (tscored > ttotal || tscored % ttotal == 0) {
      up = tscored / ttotal;
      down = 1;
    } else if (tscored < ttotal || ttotal % tscored == 0) {
      up = 1;
      down = ttotal / tscored;
    } else {
      up = tscored;
      down = ttotal;
    }
    return Grade(up, down);
  }

  Grade Grade::Plus(const Grade& rhs) const {
    unsigned int scored = scored_*rhs.total_ + rhs.scored_*total_;
    unsigned int total = total_ *rhs.total_;
    return Grade(scored, total);
  }
