// Copyright 2022 Lian
//

#include <exam2/inc/functional_array.h>
#include <exam2/inc/functional_array.h>

#include <cstddef>  // size_t
#include <iostream>
#include <fstream>

::size_t** Allocate(const ::size_t* sizes, ::size_t length) {
        size_t** all = new size_t*[length];
        for (size_t i = 0; i < length; i++) {
            all[i] = new size_t[sizes[i]];
            for (size_t j = 0; j < sizes[i]; j++) {
                all[i][j] = sizes[i];
            }
          }
        return all;
}

::size_t Deallocate(const ::size_t** delete_me,
                    const ::size_t* sizes,
                    ::size_t length) {
        size_t sum = 0;
        for (size_t i = 0; i < length; i++) {
                for (size_t j = 0; j < sizes[i]; j++) {
                       sum = sum + delete_me[i][j];
                }
         }
         for (size_t i = 0; i < length; i++) {
                delete []delete_me[i];
         }
         delete []delete_me;
         return sum;
}
