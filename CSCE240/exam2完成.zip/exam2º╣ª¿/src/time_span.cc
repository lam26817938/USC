// Copyright 2022 Lian
//

#include <exam2/inc/time_span.h>
#include <exam2/inc/time_span.h>

TimeSpan::TimeSpan() {
         hour = 0;
         minute = 0;
         second = 0;
         }

TimeSpan::TimeSpan(int hours, int minutes, int seconds) {
         hour = hours;
         minute = minutes;
         second = seconds;
         }

int TimeSpan::hours() const {
         return hour;
         }

int TimeSpan::minutes() const {
         return minute;
         }

int TimeSpan::seconds() const {
         return second;
         }

const TimeSpan TimeSpan::operator+(const TimeSpan& rhs) const {
         int hours = hour + rhs.hour;
         int minutes = minute + rhs.minute;
         int seconds = second + rhs.second;

         int th = 3600 * hours;
         int tm = 60 * minutes;
         int ts = seconds + th + tm;
         th = ts / 3600;
         tm = ts % 3600 /60;
         ts = ts - (th * 3600) - (60 * tm);

         return TimeSpan(th, tm, ts);
         }

const TimeSpan TimeSpan::operator+(int rhs) const {
         int th = 3600 * hour;
         int tm = 60 * minute;
         int ts = second + th + tm;
         ts = ts + rhs;
         th = ts / 3600;
         tm = ts % 3600 / 60;
         ts = ts - (th * 3600) - (60 * tm);

         return TimeSpan(th, tm, ts);
         }

std::istream& TimeSpan::extract(std::istream* ans) {
        std::string a = ":";
        *ans >> hour >> a >> minute >> a >> second;
        return *ans;
}

std::ostream& TimeSpan::insert(std::ostream* ans) const {
        *ans << hour << " : " << minute << " : " << second;
        return *ans;
}

// out of class
const TimeSpan operator+(int lhs, const TimeSpan& rhs) {
         return rhs.operator + (lhs);
         }

std::istream& operator>>(std::istream& lhs, TimeSpan& rhs) {
         return rhs.extract(&lhs);
         }

std::ostream& operator<<(std::ostream& lhs, const TimeSpan& rhs) {
         return rhs.insert(&lhs);
         }
