// Copyright 2022 CSCE 240
//
#ifndef HW6_INC_TEST_GRADE_H_
#define HW6_INC_TEST_GRADE_H_

#include <hw6/inc/grade.h>
#include <hw6/inc/rational.h>
#include <cstdlib>  // atoi
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>


const char *kGrade_c_str = "csce240::hw6::Grade";

#endif  // HW6_INC_TEST_GRADE_H_
