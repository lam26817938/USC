// Copyright 2022 CSCE 240
//
#ifndef HW6_INC_TEST_RATIONAL_H_
#define HW6_INC_TEST_RATIONAL_H_

#include <hw6/inc/rational.h>
#include <cstdlib>  // atoi
#include <iostream>
#include <sstream>
#include <string>
#include <vector>


const char *kRational_c_str = "csce240::hw6::Rational";

#endif  // HW6_INC_TEST_RATIONAL_H_
