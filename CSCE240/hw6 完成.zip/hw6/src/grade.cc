//  Copyright 2022 Lian Liao

#include <hw6/inc/grade.h>

using csce240::hw6::Grade;
using csce240::hw6::Rational;
using std::string;

template <class T>
Grade<T>::Grade() {
  score_ = 0;
}
template <class T>
Grade<T>::Grade(T score):Rational(score) {
  score_ = score;
}
template <class T>
T Grade<T>::score() const {
  return score_;
}
template <class T>
string Grade<T>::ToLetter() const {
    if (score_ >= 90) {
            return string("A");
    } else if (score_ >= 80) {
            return string("B");
    } else if (score_ >= 70) {
            return string("C");
    } else if (score_ >= 60) {
            return string("D");
    } else {
            return string("F");
    }
        }
template <>
string Grade<Rational>::ToLetter() const {
    double score = score_.ToDouble();
    if (score >= 90) {
            return string("A");
    } else if (score >= 80) {
            return string("B");
    } else if (score >= 70) {
            return string("C");
    } else if (score >= 60) {
            return string("D");
    } else {
            return string("F");
    }
        }
template <class T>
string Grade<T>::ToLetter(unsigned int thre) const {
    double temp = score_*1.0;
    if (round(temp) > temp && fabs(round(temp)-temp) < 0.000001*fabs(temp)) {
        temp = round(temp);
    }
    if (temp >= 100)
        return string("A+");
    double temp1 = floor(temp/10)*10;
    bool wp = false;
    if ((temp-temp1)*10 >= static_cast<int>(thre)) {
       wp = true;
    }

    if (temp >= 90) {
            return string("A")+(wp ? "+" : "");
    } else if (temp >= 80) {
            return string("B")+(wp ? "+" : "");
    } else if (temp >= 70) {
            return string("C")+(wp ? "+" : "");
    } else if (temp >= 60) {
            return string("D")+(wp ? "+" : "");
    } else {
            return string("F");
    }
        }
template <>
string Grade<Rational>::ToLetter(unsigned int thre) const {
    double temp = score_.ToDouble();
    if (round(temp) > temp && fabs(round(temp)-temp) < 0.000001*fabs(temp)) {
        temp = round(temp);
    }
    if (temp >= 100)
        return string("A+");
    double temp1 = floor(temp/10)*10;
    bool wp = false;
    double temp2 = 10*(temp-temp1);
    if (temp2 >= static_cast<int>(thre)) {
        wp = true;
    }
    if (temp >= 90) {
            return string("A")+(wp ? "+" : "");
    } else if (temp >= 80) {
            return string("B")+(wp ? "+" : "");
    } else if (temp >= 70) {
            return string("C")+(wp ? "+" : "");
    } else if (temp >= 60) {
            return string("D")+(wp ? "+" : "");
    } else {
            return string("F");
    }
        }

template <class T>
decltype(auto) Grade<T>::CalcAverage(const vector<T>& scores) {
    T sum = 0;
    for (T i : scores) {
        sum += i;
    }
    return sum/static_cast<int>(scores.size());
}
template <>
decltype(auto) Grade<Rational>::CalcAverage(const vector<Rational>& scores) {
    double sum = 0;
    for (Rational i : scores) {
        sum += i.ToDouble();
    }
    return Rational(sum, static_cast<int>(scores.size()));
}
